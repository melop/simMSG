#!/bin/bash
sCurrFolder=`pwd`
sPythonCmd=python2.7
arrChecks=( $sPythonCmd perl R php apt-get yum )
arrInfo=( "Python" "PERL" "R Language" "PHP" "apt-get (optional)" "yum (optional)" )
arrUbuntuPackage=( "$sPythonCmd" "perl" "r-base-dev" "php5-cli" "" "" )
nLen=${#arrChecks[@]}
arrNeedInstall=(  )
nNeedInstallCount=0
bDebian=0
bRedHat=0
sMSG_SimulatorDIR=../
cd $sMSG_SimulatorDIR;
sMSG_SimulatorDIR=`pwd`
sPkgSource=$sMSG_SimulatorDIR/simMSG/msg/dependencies/
sPkgTarget=$sCurrFolder/pkgs/
sConfigScript=$sCurrFolder/run.sh

bIsMacOS=0
sSystemNameStr=`uname -s`

echo ""
echo ""
echo "============= Welcome to simMSG installation ============"
echo ""
echo "   We will now attempt to automatically detect and"
echo "   install packages for you."
echo ""
echo "   The packages used by MSG will be installed to a"
echo "   private location, so that it won't interfere with"
echo "   your existing configuration."
echo ""
echo "          Make sure you have internet connection"
echo
echo "   Redhat/CentOS users: you need to have sudo rights"
echo "   ^^^^^^^^^^^^^"
echo ""
echo "========================================================"
echo ""

#Tell if is MacOS, if so, just copy the precompiled binaries.
if [[ "$sSystemNameStr" == 'Darwin' ]]; then
	bIsMacOS=1
	echo "Warning: Support for MacOS X is experimental. Use Linux if it doesn't work.";
fi


echo MSG_simulator directory: $sMSG_SimulatorDIR



cd $sCurrFolder;

for ((i=0;i<$nLen;i++))
do
	sCheck=${arrChecks[$i]}
	sInfo=${arrInfo[$i]}
	if type $sCheck 1>/dev/null 2>/dev/null ; then
		
		if [ "$sCheck" == "apt-get" ]; then
			bDebian=1 ;
		fi

		if [ "$sCheck" == "yum" ]; then
			bRedHat=1 ;
		fi

		if [ "$sCheck" == "perldoc" ]; then
			if [ `perldoc 2>&1 | grep -c "Usage: perldoc"` -eq 0 ] ; then
				echo "Perldoc missing..."
				arrNeedInstall[$nNeedInstallCount]=$i ;
				(( nNeedInstallCount++ )) ;
			fi
		fi
		echo	$sInfo:		 installed ;
	else
		
		if [[ "$sCheck" == "apt-get" || "$sCheck" == "yum" ]]; then
			continue;
		fi
		echo	$sInfo:		 MISSING! ;
		arrNeedInstall[$nNeedInstallCount]=$i ;
		(( nNeedInstallCount++ )) ;
	fi
done

if [[ ($bDebian == 0 && $bRedHat == 0) && $nNeedInstallCount -gt 0 ]]; then
	echo "Unable to automatically install packages for your system. Please install the above missing programs manually.";
	exit -1;
fi

if [[ ($bDebian == 1 || $bRedHat == 1) && $nNeedInstallCount -gt 0 ]]; then
	echo "We can attemp to execute the installation commands for the missing programs. Note that you must have administrator privilige to continue. Otherwise you must contact your administrator to install the missing packages listed above. Do you want to continue? y- yes, n-no:";
	read sUserAnswer
	if [ "$sUserAnswer" == "y" ] ; then
		echo "Executing package installer...";
		for i in ${arrNeedInstall[@]}
		do
			sPackage=${arrUbuntuPackage[$i]}
			echo Installing pacakge $sPackage ...
			if [ -z "$sPackage" ]; then
				continue;
			fi
			
			if [[ $bDebian -eq 1 ]]; then
				sCmd="sudo apt-get install "
			fi
			if [[ $bRedHat -eq 1 ]]; then
				sCmd="sudo yum install "
			fi


			if [ "$sPackage" == "python2.7" -a $bRedHat -eq 1 ]; then
				#yum groupinstall "Development tools"
				#yum -y install zlib-devel bzip2-devel openssl-devel ncurses-devel sqlite-devel readline-devel tk-devel gdbm-devel db4-devel libpcap-devel
				#yum -y install python-devel openssl openssl-devel gcc
				#wget http://python.org/ftp/python/2.7.6/Python-2.7.6.tar.xz
				#tar xf Python-2.7.6.tar.xz
				#cd Python-2.7.6
				#./configure --prefix=/usr/local --enable-unicode=ucs4 --enable-shared LDFLAGS="-Wl,-rpath /usr/local/lib"
				#if ! make ; then
			#		echo "Failed to make python 2.7";
			#		exit -1;
			#	fi

		#		if ! make altinstall; then
		#			echo "Failed to install python 2.7";
		#			exit -1;
		#		fi
							
			   if hash $sPythonCmd 2>/dev/null; then
					echo "You have python2.7 installed on Redhat/CentOS.";
				else
					echo "You don't have python2.7, try to use python2.6. If fails this is probably why.";
					sPythonCmd=python2.6
			   fi

				continue;
			fi

			if [ "$sPackage" == "r-base-dev" -a $bRedHat -eq 1 ]; then
				echo "We cannot install R for you, please do it manually. Redhat/CentOS users refer to ";
				echo "http://www.jason-french.com/blog/2013/03/11/installing-r-in-linux/";

				exit -1;
			fi

			if [ "$sPackage" == "php5-cli" -a $bRedHat -eq 1 ]; then
				$sCmd php-cli;
				continue;
			fi

			if ! $sCmd $sPackage; then
				echo "We weren't able to install the missing package automatically. Please do that manually and run this guide again.";
				exit -1;
			fi
		done
	fi


fi


#try to install hhvm
echo "HHVM allows our script to run faster than PHP. We recommend installing it."
echo "For Ubuntu users, we can attempt to install it for you, do you want to continue? You need to start this installation script with sudo to do this. y - yes, n - no"
read sUserAnswer
if [ "$sUserAnswer" == "y" ] ; then
if [[ -r /etc/lsb-release ]]; then
    . /etc/lsb-release
    if [[ $DISTRIB_ID = Ubuntu ]]; then
        wget -O - http://dl.hhvm.com/conf/hhvm.gpg.key | apt-key add -
	echo deb http://dl.hhvm.com/ubuntu $DISTRIB_CODENAME main | tee /etc/apt/sources.list.d/hhvm.list
	apt-get update
	apt-get install hhvm
    else
        echo "We can't install hhvm for you automatically. You can refer to the hhvm website for instructions."
    fi
else
    echo "We can't install hhvm for you automatically. You can refer to the hhvm website for instructions."
fi
fi

#Test if zlib is installed
echo "#include <zlib.h>" > probe.c
echo "void main() {}" >> probe.c
bZLIBInstalled=0;

if gcc probe.c -o a.out 2>/dev/null 1>&2 ; then
	bZLIBInstalled=1;
	echo "Zlib installed"
fi

rm -f a.out
rm -f probe.c

if [[ $bZLIBInstalled -eq 0 ]]; then
if [[ $bDebian -eq 1  ]]; then
echo "Installing zlib using apt-get ..."
sudo apt-get install zlibc zlib1g zlib1g-dev

	nRetCode=$?
	if [ $nRetCode -eq 0 ];then
	   echo "Success."
	else
	   echo "The zlib package failed to install. "
	   exit 1;
	fi
fi

if [[ $bRedHat -eq 1  ]]; then
echo "Installing zlib using yum ..."
sudo yum install zlibc zlib1g zlib1g-dev

	nRetCode=$?
	if [ $nRetCode -eq 0 ];then
	   echo "Success."
	else
	   echo "The zlib package failed to install. "
	   exit 1;
	fi
fi
fi


			   if hash $sPythonCmd 2>/dev/null; then
					echo "You have python2.7 installed on Redhat/CentOS.";
				else
					echo "You don't have python2.7, try to use python2.6. If fails this is probably why.";
					sPythonCmd=python2.6
			   fi

#Test if python header is installed
echo "#include <Python.h>" > probe.c
echo "void main() {}" >> probe.c
bPYTHONLibInstalled=0;

if gcc -I /usr/include/$sPythonCmd -c probe.c -o a.out 2>/dev/null 1>&2 ; then
	bPYTHONLibInstalled=1;
	echo "Python header installed"
fi

rm -f a.out
rm -f probe.c

if [[ $bPYTHONLibInstalled -eq 0 ]]; then
if [[ $bDebian -eq 1  ]]; then
echo "Installing python2.7-dev using apt-get ..."
sudo apt-get install python2.7-dev
fi
fi


# now install software and python, R packages
rm -f -r $sPkgTarget
mkdir -p $sPkgTarget
cd $sPkgTarget
sPkgTarget=`pwd` #absolute path



#Install PERL packages from source

arrPerlpkgs=( Math-Random-0.70.tar.gz )
arrPerlClass=( Math::Random )
sPerlPkgTarget=$sPkgTarget/Perl/
cd $sPkgTarget
mkdir $sPerlPkgTarget


echo "Installing perl packages..."
echo "export PERL5LIB=$sPkgTarget/Perl/lib:\$PERL5LIB;" > $sConfigScript
export PERL5LIB=$sPkgTarget/Perl/lib:$PERL5LIB;

nLen=${#arrPerlpkgs[@]}

for ((i=0;i<$nLen;i++))
do
	p=${arrPerlpkgs[$i]}
	sClass=${arrPerlClass[$i]}
	cd $sPkgTarget
	
	#First test if already installed;
	echo "use $sClass;" > test.pl;
	perl test.pl >/dev/null 2>&1;
	nRetCode=$?;
	
	if [ $nRetCode -eq 0 ]; then
		echo $sClass already installed.
		continue;
	fi
	
	echo Installing Perl package $p ...
	cp $sPkgSource/$p ./
	chmod 777 ./*
	tar -xzvf $p > tartmp.txt 2>&1
	#sPkgDIR=`head -n 1 < tartmp.txt | grep -P -o "[^\\]*[^\/]+[\\\/]"`
	sPkgDIR=`echo $p | sed -E s/\.tar.*//`
	cd $sPkgDIR
	perl Makefile.PL PREFIX=$sPkgTarget/Perl LIB=$sPkgTarget/Perl/lib INSTALLMAN1DIR=$sPkgTarget/Perl/man1 INSTALLMAN3DIR=$sPkgTarget/Perl/man3 INSTALLSITEMAN1DIR=$sPkgTarget/Perl/man1 INSTALLVENDORMAN1DIR=$sPkgTarget/Perl/man1 INSTALLSITEMAN3DIR=$sPkgTarget/Perl/man3 INSTALLVENDORMAN3DIR=$sPkgTarget/Perl/man3 > ../perl_$p.log 2>&1;

	#INSTALLSITEMAN3DIR=$sPkgTarget/Perl/man3 INSTALLSITEMAN1DIR=$sPkgTarget/Perl/man1 INSTALLMAN1DIR=$sPkgTarget/Perl/man1 INSTALLMAN3DIR=$sPkgTarget/Perl/man3
	#FIX THE MAKEFILE!

	sESCPkgTarget=$(echo $sPkgTarget/Perl | sed "s|\/|\\\/|g")

	if [[ $bIsMacOS == 1 ]]; then
		echo -ne "";
	else 
		mv Makefile Makefile.bak
		sed -e "s/^PREFIX\s*=.*$/PREFIX = $sESCPkgTarget/" Makefile.bak > Makefile
	fi
	
	make >> ../perl_$p.log 2>&1;
	make test >> ../perl_$p.log 2>&1;
	make install >> ../perl_$p.log 2>&1;
	
	nRetCode=$?
	if [ $nRetCode -eq 0 ];then
	   echo "Success."
	else
	   echo "The above Perl package failed to install. Please check log files."
	   exit 1;
	fi

	cd $sPkgTarget
	rm -f $p
	rm -fr $sPkgDIR
done



#make bwa
cd $sPkgTarget
echo Installing bwa...
if [[ $bIsMacOS == 1 ]]; then
	echo "Copying binary for MacOS..."
	cp -r $sPkgSource/macos/bwa-0.5.7/ ./bwa-0.5.7/;
	cd bwa-0.5.7 ;
else
	cp $sPkgSource/bwa-0.5.7.tar.bz2 ./ ;
	tar -jxf bwa-0.5.7.tar.bz2;
	cd bwa-0.5.7 ;
	make > ../bwainstall.log 2>&1 ;

	nRetCode=$?
	if [ $nRetCode -eq 0 ];then
	   echo "Success."
	else
	   echo "Failed to make bwa."
	   exit 1;
	fi
	
fi
sBWAPath=`pwd` ;
echo "export PATH=$sBWAPath:\$PATH;" >> $sConfigScript ;


cd $sPkgTarget

#make samtools
echo Installing samtools...

if [[ $bIsMacOS == 1 ]]; then
	echo "Copying binary for MacOS..."
	cp -r $sPkgSource/macos/samtools-0.1.9/ ./samtools-0.1.9/;
	cd samtools-0.1.9 ;
else
	cp $sPkgSource/samtools-0.1.9.tar.bz2 ./
	tar -jxf samtools-0.1.9.tar.bz2
	cd samtools-0.1.9
	make > ../samtoolsinstall.log 2>&1

	nRetCode=$?
	if [ $nRetCode -eq 0 ];then
	   echo "Success."
	else
	   echo "Failed to make samtools."
	   exit 1;
	fi
fi

sSAMPATH=`pwd`
echo "export PATH=$sSAMPATH:\$PATH;" >> $sConfigScript


cd $sPkgTarget

#make twopopfreqs
echo Installing twopopfreqs...
mkdir -p utils
cd ./utils/ ;

if [[ $bIsMacOS == 1 ]]; then
	echo "Copying binary for MacOS..."
	cp $sPkgSource/macos/twopopfreq ./;
	
else
	cp $sPkgSource/twopopfreq.c ./;
	chmod 777 ./*
	gcc -x c twopopfreq.c -o twopopfreq -lm

	nRetCode=$?
	if [ $nRetCode -eq 0 ];then
	   echo "Success."
	else
	   echo "twopopfreq failed to compile. "
	   exit 1;
	fi
fi

sTWOPOPPATH=`pwd`
echo "export PATH=$sTWOPOPPATH:\$PATH;" >> $sConfigScript


#make seqtk
cd $sPkgTarget
echo Installing seqtk...
mkdir -p utils
cd ./utils/ ;

if [[ $bIsMacOS == 1 ]]; then
	echo "Copying binary for MacOS..."
	#cp $sPkgSource/macos/twopopfreq ./;
	
else
	cp $sPkgSource/seqtk_source.tar.gz ./;

	tar -xzf seqtk_source.tar.gz
	cd seqtk_source
	make > ../seqtkinstall.log 2>&1

	nRetCode=$?
	if [ $nRetCode -eq 0 ];then
	   echo "Success."
	else
	   echo "Failed to make seqtk."
	   exit 1;
	fi
fi

sSEQTKPATH=`pwd`
echo "export PATH=$sSEQTKPATH:\$PATH;" >> $sConfigScript






cd $sPkgTarget

#install R packages
arrRpkgs=( R.methodsS3_1.2.0.tar.gz R.oo_1.7.3.tar.gz zoo_1.7-9.tar.gz HiddenMarkov_1.3-1.tar.gz )
sRPkgTarget=$sPkgTarget/R/
mkdir $sRPkgTarget

echo "export R_LIBS=$sRPkgTarget:\$R_LIBS;" >> $sConfigScript
echo "export R_LIBS_SITE=$sRPkgTarget:\$R_LIBS_SITE;" >> $sConfigScript
echo "export R_LIBS_USER=$sRPkgTarget:\$R_LIBS_USER;" >> $sConfigScript

export R_LIBS=$sRPkgTarget:\$R_LIBS;
export R_LIBS_SITE=$sRPkgTarget:\$R_LIBS_SITE;
export R_LIBS_USER=$sRPkgTarget:\$R_LIBS_USER;

for p in ${arrRpkgs[@]}
do
	echo Installing R package $p ...
	R CMD INSTALL -l $sRPkgTarget $sPkgSource/$p > ./R_pkg_$p.log 2>&1 ; 

	nRetCode=$?
	if [ $nRetCode -eq 0 ];then
	   echo "Success."
	else
	   echo "The above R package failed to install. Please check log files."
	   exit 1;
	fi
done

#install python packages
alias python=$sPythonCmd

arrPythonpkgs=( numpy-1.5.1.tar.gz biopython-1.53.tar.gz pyfasta-0.4.3.tar.gz Pyrex-0.9.9.tar.gz pysam-0.7.5.tar.gz )
sPyPkgTarget=$sPkgTarget/Python/
cd $sPkgTarget
mkdir $sPyPkgTarget
mkdir -p $sPyPkgTarget/lib/$sPythonCmd/site-packages/
mkdir -p $sPyPkgTarget/lib64/$sPythonCmd/site-packages/
export PYTHONPATH=$sPyPkgTarget/lib/$sPythonCmd/site-packages/:$PYTHONPATH;
export PYTHONPATH=$sPyPkgTarget/lib64/$sPythonCmd/site-packages/:$PYTHONPATH;
echo "export PYTHONPATH=$sPyPkgTarget/lib/$sPythonCmd/site-packages/:\$PYTHONPATH;" >> $sConfigScript
echo "export PYTHONPATH=$sPyPkgTarget/lib64/$sPythonCmd/site-packages/:\$PYTHONPATH;" >> $sConfigScript

#Check if setuptools are installed
echo "import sys" > test.py
echo "try:" >> test.py
echo "	import setuptools" >> test.py
echo "except ImportError:" >> test.py
echo "	sys.exit(1)" >> test.py
echo "else:" >> test.py
echo "	sys.exit(0)" >> test.py

$sPythonCmd test.py >/dev/null 2>&1

nRetCode=$?
if [ $nRetCode -eq 0 ];then
echo "setuptools installed."
else

#First install setuptools
    if hash easy_install 2>/dev/null; then
        echo "Setuptools already installed. Continue with python package installation."
    else
        echo "Setuptools not found on your system. We will now try to install this, but in case it fails, please do so manually and restart the installation."
		echo Installing setuptools...
		#ln -s $sPkgSource/ez_setup.py ./
		if [[ $bIsMacOS == 1 ]]; then
			curl https://bitbucket.org/pypa/setuptools/raw/bootstrap/ez_setup.py > ez_setup.py
		else
			wget https://bitbucket.org/pypa/setuptools/raw/bootstrap/ez_setup.py
		fi

		$sPythonCmd ez_setup.py --user > ezsetup.log 2>&1

			nRetCode=$?
			if [ $nRetCode -eq 0 ];then
			   echo "Success."
			else
			   echo "Python setuptools failed to install. Make sure you have internet connection."
			   exit 1;
			fi
		fi

    fi
	


for p in ${arrPythonpkgs[@]}
do
	cd $sPkgTarget
	echo Installing Python package $p ...
	cp $sPkgSource/$p ./
	chmod 777 ./*
	tar -xzvf $p > tartmp.txt 2>&1
	#sPkgDIR=`head -n 1 < tartmp.txt | grep -P -o "[^\\]*[^\/]+[\\\/]"`
	sPkgDIR=`echo $p | sed -E s/\.tar.*//`
	cd $sPkgDIR

	sINCPath="/usr/local/include/$sPythonCmd/"

	if [ $bRedHat -eq 1 ]; then
		if [[ "$p" == "numpy-1.5.1.tar.gz" ]]; then
			sudo yum install atlas-devel
		fi

		$sPythonCmd setup.py build > ../python_$p.log 2>&1  #-I $sINCPath
	else
		$sPythonCmd setup.py build > ../python_$p.log 2>&1
	fi 

	$sPythonCmd setup.py install --prefix="$sPyPkgTarget" >> ../python_$p.log 2>&1

	nRetCode=$?
	if [ $nRetCode -eq 0 ];then
	   echo "Success."
	else
	   echo "The above package failed to install. Please check log files."
	   exit 1;
	fi

	cd $sPkgTarget
	rm -f $p
	rm -r $sPkgDIR
done


echo "Making MSG binaries ..."
cd $sMSG_SimulatorDIR/simMSG/msg/
make all > $sPkgTarget/make_msg.log 2>&1

	nRetCode=$?
	if [ $nRetCode -eq 0 ];then
	   echo "Success."
	else
	   echo "The MSG binaries failed to make. "
	   exit 1;
	fi

chmod 777 *
sPython27RealPath=`which $sPythonCmd`;

cd $sPkgTarget

echo "" >> $sConfigScript;
echo "alias sh=bash" >> $sConfigScript;
echo "alias python=$sPython27RealPath" >> $sConfigScript;
echo "" >> $sConfigScript;
#echo "cd ../MSG_simulator/" >> $sConfigScript;
echo ""; >> $sConfigScript

echo 'BASEDIR=$(dirname $0)' >> $sConfigScript;
echo 'perl $BASEDIR/simulateMSG.pl -c $1'>> $sConfigScript;

cp $sConfigScript $sMSG_SimulatorDIR/runsimmsg.sh
chmod 755 $sMSG_SimulatorDIR/*.sh
echo Installation completed.
echo  "==========================================="
echo "If you want to run simMSG from any folder, "
echo "appened the following line to the end of the "
echo ".profiles file inside your home folder "
echo "(this file is hidden by default):";
echo "PATH=$sMSG_SimulatorDIR/:\$PATH"
echo  "==========================================="

echo "PATH=$sMSG_SimulatorDIR/:\$PATH" > addmetoprofile.txt
