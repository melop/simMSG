#perl! -w
#Molly
#Ray biubiubiubiubiu
use Getopt::Long 2.17;
use Cwd 'abs_path';
use Data::Dumper;
use File::Copy;
use File::Basename;
use POSIX;

my $sScriptPath=abs_path($0);
$sScriptPath =~ s/(.+[\\\/])[^\\^\/]+$/\1/;


#########DEFINE SIMULATION PARAMTERS
my $par1 = "";
my $par2 = "";
my $genome_size="";
my $rate= "";
my $chrom = "";
my $sexchroms=NULL;
my $gen  = "";
my $prop_par1 = "";
my $prop_par2 = "";
my $poly_par1 = "";
my $poly_par2 = "";
my $poly_ancestral = "";
my $dxy_par1_par2 = "";
my $mask_poly = "";
my $num_reads = "";
my $read_length = "";
my $rfac="";
my $results_folder="";
my $num_indiv="";
my $msg_error="";
my $sequencing_error="";
my $range1="";
my $range2="";
my $range3="";
my $par1_block_dist="";
my $par2_block_dist="";
my $genomic_reads="";
my $bc_parent="";
my $msg_priors="";
my $save="";
my $hsConfigs={};
my $sConfigFileName="";
my $sConfigFolder="";
my $sPhpCmd = "php ";

if (system("hash hhvm >/dev/null 2>&1") == 0) {
	print("Using hhvm instead of php\n");
	$sPhpCmd = "hhvm "
} 

GetOptions('config|c=s' => \$sConfigFileName) 
or die("Please specify configuration file name: perl simulateMSG.pl -c config_name.cfg."); 

########READ IN SIMULATION PARAMTERS

open (IN,$sConfigFileName) || die "ERROR: Can't open $sConfigFileName: $!\n";

###Obtain path of config file. All reference genome paths will be relative to the config file
$sConfigFolder = abs_path($sConfigFileName);
$sConfigFolder =~ s/(.+[\\\/])[^\\^\/]+$/\1/;
my $sConfigFileNamePure = abs_path($sConfigFileName);
$sConfigFileNamePure =~ s/.+[\\\/]([^\\^\/]+)$/\1/;

while (<IN>) { chomp $_;
	       next if ($_ =~ /^\#/);
	       next unless ($_);
	       my ($key,$val) = split(/=/,$_,2);
	       #print "$key\t$val\n";
		chomp($key);
		chomp($val);
               $hsConfigs->{lc($key)} = $val;
} close IN;

print Dumper($hsConfigs);

$par1=$hsConfigs->{'par1'};
$par2=$hsConfigs->{'par2'};
$genome_size=$hsConfigs->{'genome_size'};
$rate=$hsConfigs->{'rate'};
$chrom=$hsConfigs->{'chrom'};
$gen=int($hsConfigs->{'gen'});
$prop_par1=$hsConfigs->{'prop_par1'};
$prop_par2=$hsConfigs->{'prop_par2'};
$poly_par1=$hsConfigs->{'poly_par1'};
$poly_par2=$hsConfigs->{'poly_par2'};
$poly_ancestral=$hsConfigs->{'poly_ancestral'};
$dxy_par1_par2=$hsConfigs->{'dxy_par1_par2'};
$mask_poly=$hsConfigs->{'mask_poly'};
$num_reads=int($hsConfigs->{'num_reads'});
$read_length=int($hsConfigs->{'read_length'});
$rfac=$hsConfigs->{'rfac'};
$results_folder=$hsConfigs->{'folder'};
$num_indiv=$hsConfigs->{'num_indiv'};
$msg_error=$hsConfigs->{'msg_error'};
$sequencing_error=$hsConfigs->{'sequencing_error'};
$range1=$hsConfigs->{'range1'};
$range2=$hsConfigs->{'range2'};
$range3=$hsConfigs->{'range3'};
$genomic_reads=$hsConfigs->{'genomic_reads'};
$bc_parent=$hsConfigs->{'bc_parent'}; chomp $bc_parent;
$par1_block_dist=defined($hsConfigs->{'par1_block_dist'})? $hsConfigs->{'par1_block_dist'} : "";
$par2_block_dist=defined($hsConfigs->{'par2_block_dist'})? $hsConfigs->{'par2_block_dist'} : "";
$msg_priors=$hsConfigs->{'msg_priors'};
$save=$hsConfigs->{'save_files'};
$cluster=$hsConfigs->{'cluster'};


#Number of computer nodes to use for MSG's STEP 1
$nodes1=$hsConfigs->{'nodes1'};

#Number of CPUs to use per node for MSG's STEP 1
$ppn1=$hsConfigs->{'ppn1'};

#Maximum time limit (hh:mm:ss) for MSG's STEP 1. Check your cluster's limits.
$walltime1=$hsConfigs->{'walltime1'};

#Number of computer nodes to use for MSG's STEP 2
$nodes2=$hsConfigs->{'nodes2'};

#Number of CPUs to use per node for MSG's STEP 2
$ppn2=$hsConfigs->{'ppn2'};

#Maximum time limit (hh:mm:ss) for MSG's STEP 2. Check your cluster's limits.
$walltime2=$hsConfigs->{'walltime2'};

#Number of computer nodes to use for MSG's STEP 3
$nodes3=$hsConfigs->{'nodes3'};

#Number of CPUs to use per node for MSG's STEP 3
$ppn3=$hsConfigs->{'ppn3'};
$walltime3=$hsConfigs->{'walltime3'};

#Number of job arrays to submit
my $barcodes_per_job = 4;

if ($cluster!=0) {
	my $nTotalCores = $nodes2 * $ppn2;
	$barcodes_per_job = ceil($num_indiv / ($nodes2 + 0.00));
	print("Will use $ppn2 x $nodes2 = $nTotalCores cores, and distributing $barcodes_per_job individual(s) per node for a total of $num_indiv individuals.\n");
}

##########MAKE A NEW FOLDER FOR ANALYSIS

#This will not overwrite previous results
#Instead a number will be appended to the folder name for different runs.
my $nFolderAppendix = -1;
my $sFolderNameWApp = $results_folder;
while(1) {
	$nFolderAppendix++;
	$sFolderNameWApp = $results_folder;
	$sFolderNameWApp .= ($nFolderAppendix)? "_".$nFolderAppendix:"";

	if (! -e $sFolderNameWApp){
	    	system("mkdir $sFolderNameWApp");
		last;
	    }
}

$results_folder = $sFolderNameWApp;

chomp $par1_block_dist;
chomp $par2_block_dist;

#If user has provided parental distributions, copy these two files to the working directory.
if (($par1_block_dist !~ /NULL/) && ($par2_block_dist !~ /NULL/)) {
	copy($par1_block_dist, "$results_folder/$par1_block_dist") or die("Failed to copy user-specified block size distribution file $par1_block_dist\n");
	copy($par2_block_dist, "$results_folder/$par2_block_dist") or die("Failed to copy user-specified block size distribution file $par2_block_dist\n");
}

print("Results folder: $results_folder \n");

chdir "$results_folder" or die "can't accesss results folder";
system("ln -s $sScriptPath/simMSG/* ./ ");
system("ln -s $sConfigFolder/$par1 ./");
system("ln -s $sConfigFolder/$par2 ./");
system("cp $sConfigFolder/$sConfigFileNamePure ./");

my $path=qx(pwd);
chomp $path;

$ENV{PATH} = "$ENV{PATH}:$path";

#########EXTRACT FOCAL CHROMOSOME

my $fasta_name1="parent1.fa";my $fasta_name2="parent2.fa";
system("perl getScaffold_samtools.pl ".basename($par1)." $chrom > $fasta_name1");
system("perl getScaffold_samtools.pl ".basename($par2)." $chrom > $fasta_name2");

#########DETERMINE RELATIVE NUMBER OF READS FOR FOCAL CHROMOSOME                        
                               
open FOCAL, "$fasta_name1" or die "can't find chrom_size"; my $chrom_size=0;
while (my $line_chrom=<FOCAL>){
    chomp $line_chrom;
    $line_chrom =~ s/\s+//g;
    if ($line_chrom !~ /\>/g){
	$chrom_size += length($line_chrom);
    }
}

chomp $genome_size;
my $genome_size_bp=1000000*$genome_size;
#print "$genome_size\t$genome_size_bp\n";

my $proportion=$chrom_size/$genome_size_bp;
my $effective_reads_pre_error=int($proportion*$num_reads);

##calculate number of reads that are required to generate error
my $error_reads_par1=int($msg_error*$effective_reads_pre_error);
my $error_reads_par2=int($msg_error*$effective_reads_pre_error);

my $effective_reads=$effective_reads_pre_error-($error_reads_par1+$error_reads_par2);

print "number of reads simulated for $chrom: $effective_reads\n";
print "number of error reads simulated: $error_reads_par1\n";

#########DETERMINE SHARED POLYMORPHISM##########

if (($poly_par1 <= 0) or ($poly_par2 <= 0)){
    die "PROGRAM STOPPED: polymorphism parameters for the parental species must be greater than 0\n";
}

#calculate divergence parameters
my $div=0;
if ($dxy_par1_par2 =~ /NULL/){
    $div = qx(perl fa2div_simMSG.pl parent1.fa parent2.fa focalchrom1);
    chomp $div;
} #if user does not define dxy, calculate it based on the input genomes
else{
    $div=$dxy_par1_par2;
} #if user defines dxy

my $total_theta_par1=$chrom_size*$poly_par1;
my $total_theta_par2=$chrom_size*$poly_par2;

my $total_theta_ancestor=0; my $theta_anc=0; my $tau=0;
if($poly_ancestral =~ /NULL/){
    $total_theta_ancestor=(($total_theta_par1+$total_theta_par2)/2);
    $theta_anc=($poly_par1+$poly_par2)/2;
    $tau=(($div/$theta_anc)-1)*$total_theta_ancestor;
} #if user does not define ancestral theta
else{
    $total_theta_ancestor=$chrom_size*$poly_ancestral;    
    $tau=(($div/$poly_ancestral)-1)*$total_theta_ancestor;
} # if user defines ancestral theta

my $num_chrom=2*$num_indiv;

#Run Wakeley and Hey program to calculate polymorphism parameters for the focal chromosome
system("twopopfreq $num_chrom $num_chrom $total_theta_par1 $total_theta_par2 $total_theta_ancestor $tau > poly_stats");

print "input parameters to twopopfreq program: $num_chrom\t$num_chrom\t$total_theta_par1\t$total_theta_par2\t$total_theta_ancestor\t$tau\n";

open POLY_STATS,"poly_stats" or die "error in shared polymorphism calculations\n"; my $shared_poly=0; my $num_poly_par1=0; my $num_poly_par2=0; my $true_aims=0;
while (my $poly=<POLY_STATS>){
    chomp $poly;  
    my @poly_stats=split(/\t/, $poly);
    $shared_poly=int($poly_stats[2]);
    $num_poly_par1=int($poly_stats[0]);
    $num_poly_par2=int($poly_stats[1]);
    $true_aims=int($poly_stats[3]);
}


if(($shared_poly > 0)&&((abs($shared_poly)+abs($num_poly_par1)+abs($num_poly_par2)+abs($true_aims)) < $chrom_size)&&($num_poly_par1>0)&&($num_poly_par2>0)){
    open POLY, ">expected_shared_polymorphism";
    for $u (1..$shared_poly){
	print POLY "0.5\n";
	#set frequency of all shared polymorphisms to 0.5
    }
    system("Rscript calculate_shared_poly.R $num_chrom $num_poly_par1 $num_poly_par2");
    #generate frequency of private polymorphisms from the site frequency spectrum
} #if polymorphism calculations were successful, generate files for next step in analysis
else{#added here to warn when polymorphism calculations are inaccurate
 
   print "WARNING: SHARED POLYMORPHISM CALCULATED TO BE ZERO, CHECK POLY_STATS OUTPUT FILE\n";

    open POLY, ">expected_shared_polymorphism";
    print POLY "0\n";
    $num_poly_par1=$chrom_size*$poly_par1;
    $num_poly_par2=$chrom_size*$poly_par2;

   if(($true_aims>$chrom_size) or ($true_aims <= 0)){

       die "ERROR: AN ERROR OCCURRED CALCULATING TRUE ANCESTRY INFORMATIVE SITES OR NO SITES PREDICTED TO BE AIMS, CHECK POLY_STATS OUTPUT FILE\nPROGRAM TERMINATING\n";
       
   }

    system("Rscript calculate_shared_poly.R $num_chrom $num_poly_par1 $num_poly_par2");

}#else polymorphism calculations were unsuccessful, WARN and generate files for next step in analysis 

########RUN PHP SCRIPT TO GENERATE HYBRID CHROMOSOMES AND ADD PARENTAL POLYMORPHISMS
if ($bc_parent =~ /NULL/){

         if (($par1_block_dist !~ /NULL/)&&($par2_block_dist !~ /NULL/)){

my $sCmd = "$sPhpCmd get_hybrid_genomes_log_normal_twoparental_polymorphisms.php -A $true_aims -r $num_indiv -o hybrid_genomes -1 $fasta_name1 -2 $fasta_name2 -a m -b b -f focalchrom1 -t focalchrom1 -p polymorphism_distribution_par1 -q polymorphism_distribution_par2 -P expected_shared_polymorphism -x $par1_block_dist -y $par2_block_dist > hybrid_genomes_log";
system($sCmd);
system("ln -s ./hybrid_genomes/ref* ./");

          }
      else{

my $sCmd = "$sPhpCmd get_hybrid_genomes_log_normal_twoparental_polymorphisms.php -A $true_aims -r $num_indiv -o hybrid_genomes -1 $fasta_name1 -2 $fasta_name2 -a m -b b -f focalchrom1 -t focalchrom1 -p polymorphism_distribution_par1 -q polymorphism_distribution_par2 -P expected_shared_polymorphism -B \"Rscript exp.R $prop_par2 $gen $rate\" > hybrid_genomes_log";
system($sCmd);
system("ln -s ./hybrid_genomes/ref* ./");

       }

}#if backcross parent is not defined
else{
         if (($par1_block_dist !~ /NULL/)&&($par2_block_dist !~ /NULL/)){

my $sCmd = "$sPhpCmd get_hybrid_genomes_log_normal_twoparental_polymorphisms.php -A $true_aims -r $num_indiv -o hybrid_genomes -1 $fasta_name1 -2 $fasta_name2 -a m -b b -f focalchrom1 -t focalchrom1 -p polymorphism_distribution_par1 -q polymorphism_distribution_par2 -P expected_shared_polymorphism -x $par1_block_dist -y $par2_block_dist -C $bc_parent > hybrid_genomes_log";

system($sCmd);
system("ln -s ./hybrid_genomes/ref* ./");
        }
        else{
my $sCmd = "$sPhpCmd get_hybrid_genomes_log_normal_twoparental_polymorphisms.php -A $true_aims -r $num_indiv -o hybrid_genomes -1 $fasta_name1 -2 $fasta_name2 -a m -b b -f focalchrom1 -t focalchrom1 -p polymorphism_distribution_par1 -q polymorphism_distribution_par2 -P expected_shared_polymorphism -C $bc_parent -B \"Rscript exp.R $prop_par2 $gen $rate\" > hybrid_genomes_log";

system($sCmd);
system("ln -s ./hybrid_genomes/ref* ./");
        }
     }#if there is a defined backcross parent

###########MASK POLYMORPHIC SITES IN REFERENCE GENOMES IF DESIRED

my $masked_fasta1=""; my $masked_fasta2="";
if ($mask_poly == 1){
    system("perl identify_polymorphic_sites.pl $num_indiv");
    $masked_fasta1="$fasta_name1"."_masked";
    system("./seqtk_source/seqtk mutfa $fasta_name1 ./hybrid_genomes/polymorphic_sites.insnp > $masked_fasta1");
    $masked_fasta2="$fasta_name2"."_masked";
    system("./seqtk_source/seqtk mutfa $fasta_name2 ./hybrid_genomes/polymorphic_sites.insnp > $masked_fasta2");
}


##########WRITE MSG.CFG file                                                                                                       

open OUT_CFG, ">msg.cfg";
print OUT_CFG "cluster=$cluster\nqueue=1day\nbarcodes=barcodes_file\nreads=reads.fq\nre_cutter=MseI\nlinker_system=Dros_SR_vII\n";

if ($mask_poly == 1){
print OUT_CFG "parent1=$masked_fasta1\nparent2=$masked_fasta2\nbwaindex1=bwtsw\nbwaindex2=bwtsw\nupdate_minQV=1\nmin_coverage=1\nchroms=focalchrom1\nsexchroms=$sexchroms\nchroms2plot=group1\n";
}
else{
print OUT_CFG "parent1=$fasta_name1\nparent2=$fasta_name2\nbwaindex1=bwtsw\nbwaindex2=bwtsw\nupdate_minQV=1\nmin_coverage=1\nchroms=focalchrom1\nsexchroms=$sexchroms\nchroms2plot=group1\n";
}
print OUT_CFG "nodes1=$nodes1\n";
print OUT_CFG "nodes2=$nodes2\n";
print OUT_CFG "nodes3=$nodes3\n";
print OUT_CFG "ppn1=$ppn1\n";
print OUT_CFG "ppn2=$ppn2\n";
print OUT_CFG "ppn3=$ppn3\n";
print OUT_CFG "walltime1=$walltime1\n";
print OUT_CFG "walltime2=$walltime2\n";
print OUT_CFG "walltime3=$walltime3\n";
print OUT_CFG "barcodes_per_job=$barcodes_per_job\n";

my $hw_par1=$prop_par1**2;
my $hw_par2=$prop_par2**2;
my $hw_hets=2*$prop_par1*$prop_par2;

my $rec_rate=(($rate*($chrom_size/1000))/100)*$gen;

if($msg_priors == 0){
print OUT_CFG "priors=$hw_par1,$hw_hets,$hw_par2\ndeltapar1=$msg_error\ndeltapar2=$msg_error\nrecRate=$rec_rate\nrfac=$rfac\npnathresh=.03\none_site_per_contig=1\ntheta=0.5\n";
}
if($msg_priors == 1){
print OUT_CFG "priors=0.33,0.33,0.33\ndeltapar1=$msg_error\ndeltapar2=$msg_error\nrecRate=$rec_rate\nrfac=$rfac\npnathresh=.03\none_site_per_contig=1\ntheta=0.5\n";
}

#########WRITE BARCODES FILE AND READS.FQ

open BARCODES, ">barcodes_file";

for $k (0..($num_indiv-1)){
    print BARCODES "ATGACA\t$k\n";
}

open READS, ">reads.fq";
print READS "reads.fq\n";

########RUN READ SIMULATOR

my $foldername="reads.fq_parsed";
if (! -e $foldername){
    system("mkdir $foldername");
}

#****GENERATE READS AND ERROR READS FROM THE PARENTAL GENOMES**#
if($genomic_reads == 0){
my $read_index1=$effective_reads;
my $read_index2=$read_index1+$error_reads_par1;
my $haplotype_reads=$effective_reads/2;

for $i (0..($num_indiv-1)){
    my $output_name="indiv"."$i"."_ATGACA.gz";
    my $input_name_hap1="$i"."_genome_hap1.txt";
    my $input_name_hap2="$i"."_genome_hap2.txt";

    system("cat ./hybrid_genomes/$input_name_hap1 | perl simulate_SRshortreads_MSG_sim.pl $read_length $haplotype_reads 300 600 $sequencing_error 0 > reads_sim.fq");
    system("cat ./hybrid_genomes/$input_name_hap2 | perl simulate_SRshortreads_MSG_sim.pl $read_length $haplotype_reads 300 600 $sequencing_error $haplotype_reads >> reads_sim.fq");
    system("cat ./hybrid_genomes/ref_genome_1.txt | perl simulate_SRshortreads_MSG_sim.pl $read_length $error_reads_par1 300 600 $sequencing_error $read_index1 >> reads_sim.fq");
    system("cat ./hybrid_genomes/ref_genome_2.txt | perl simulate_SRshortreads_MSG_sim.pl $read_length $error_reads_par2 300 600 $sequencing_error $read_index2 >> reads_sim.fq");
    system("cat reads_sim.fq | gzip > ./$foldername/$output_name");
}

} #simulate reads at MseI sites

elsif($genomic_reads == 1){
    my $read_index1=$effective_reads;
    my $read_index2=$read_index1+$error_reads_par1;
    my $haplotype_reads=$effective_reads/2;

    for $i (0..($num_indiv-1)){
	my $output_name="indiv"."$i"."_ATGACA.gz";
	my $input_name_hap1="$i"."_genome_hap1.txt";
	my $input_name_hap2="$i"."_genome_hap2.txt";
	
	system("cat ./hybrid_genomes/$input_name_hap1 | perl simulate_SRshortreads_continuous_sim.pl $read_length $haplotype_reads 300 600 $sequencing_error 0 > reads_sim.fq");
        system("cat ./hybrid_genomes/$input_name_hap2 | perl simulate_SRshortreads_continuous_sim.pl $read_length $haplotype_reads 300 600 $sequencing_error $haplotype_reads >> reads_sim.fq");
        system("cat ./hybrid_genomes/ref_genome_1.txt | perl simulate_SRshortreads_continuous_sim.pl $read_length $error_reads_par1 300 600 $sequencing_error $read_index1 >> reads_sim.fq");
        system("cat ./hybrid_genomes/ref_genome_2.txt | perl simulate_SRshortreads_continuous_sim.pl $read_length $error_reads_par2 300 600 $sequencing_error $read_index2 >> reads_sim.fq");
	system("cat reads_sim.fq | gzip > ./$foldername/$output_name");
    }

} #simulate reads randomly throughout the genome sites

########RUN MSG

system("perl ./msg/msgCluster.pl > msg_error_log");

########RUN PHP SCRIPTS TO CHECK MSG ACCURACY

system("$sPhpCmd blockmsgAccuracy.php -1 ancestry-probs-par1.tsv -2 ancestry-probs-par2.tsv -3 ancestry-probs-par1par2.tsv -i hybrid_genomes -f filterlist.txt -p 0.95 -l 2000 -o accuracy.txt");

system("$sPhpCmd GenomeLenMsgAccuracy.php -1 ancestry-probs-par1.tsv -2 ancestry-probs-par2.tsv -3 ancestry-probs-par1par2.tsv -i hybrid_genomes -p 0.95 -l 2000 -o genomelen_acc.txt");

########OUTPUT INDIVIDUAL ANCESTRY 

system("perl parsetsv_priors.pl ancestry-probs-par1.tsv ancestry-probs-par2.tsv 0.95 > individual_priors");

########INTERPRET ERROR FILE

open SUMMARY, ">Simulation_results_summary.txt";
print SUMMARY "Simulation results for chromosome: "."$chrom"." in "."$par1"." x "."$par2"." hybrids"."\n";
(my $blocksize1, my $blocksize2)=split(/-/,$range1); chomp $blocksize1; chomp $blocksize2;
(my $blocksize3, my $blocksize4)=split(/-/,$range2); chomp $blocksize3; chomp $blocksize4;
(my $blocksize5, my $blocksize6)=split(/-/,$range3); chomp $blocksize5; chomp $blocksize6;
print "$blocksize1 $blocksize2 $blocksize3 $blocksize4 $blocksize5 $blocksize6\n";
system("Rscript Analyze_accuracy.R $blocksize1 $blocksize2 $blocksize3 $blocksize4 $blocksize5 $blocksize6 $chrom_size $hw_par1 $hw_hets $hw_par2");
system("perl -pi -e 's/\"//g' Simulation_results_summary.txt");

########CLEANUP

if ($save==0){
system("sh cleanup");
#cleanup intermediate files
}

