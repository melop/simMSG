<?php
ini_set ( "memory_limit", -1 );
$sGenotypeFilePop1 = "ancestry-probs-par1.tsv";
$sGenotypeFilePop2 = "ancestry-probs-par2.tsv";
$sGenotypeFileHetero = "ancestry-probs-par1par2.tsv";
$nCutoffProb = 0.95;
$nScfldLimit = 2000; 
$sOut= "blocksize.txt";
$nMinAlleles = 0;
$nSL = 0.0; 
$bNoMissing = false;
$sPregFileStem = "/indiv(\d+)\_/";
$nIndIndexOffset = 0;

$arrStatesInAncestry = array(0, 1 , 2);
$arrStatesInMSG= array(0, 1 , 2, -1);
$arrAncestryVals = array("b"=> 0, "m" => 1 );
$arrOutFileHandlers = array();

foreach($arrStatesInMSG as $nState) {
	$arrOutFileHandlers[$nState] = fopen($nState."_".$sOut, "w");
}

$arrExcludeList = array("null");

$hGenotypeFilePop1 = fopen($sGenotypeFilePop1 , "r");
$hGenotypeFilePop2 = fopen($sGenotypeFilePop2 , "r");
$hGenotypeFileHetero = fopen($sGenotypeFileHetero , "r");
$hFilterList = false;
$hOut= fopen($sOut, "w");

$arrFilterList = array();

$bNoFilterList = false;

if ($hFilterList == false) {
	$bNoFilterList = true;
	echo("No filter list specified, will output all samples\n");
}
else {

	while(($sLn = fgets($hFilterList ))!==false) {

		array_push($arrFilterList , trim($sLn));

	}
}


$arrMatrix = array();
$arrMask = array();
$arrExcludeSites = array();
$arrCoordinates = array();
$arrFlatCoordinates = array();
$nLnCount = -1;
$nSampleCount = 0;
echo("Reading genotype file...\n");
$arrStateTransitionMatrix = array();

while(($sLnPop1 = fgets($hGenotypeFilePop1))!==false && ($sLnPop2 = fgets($hGenotypeFilePop2))!==false && ($sLnHetero = fgets($hGenotypeFileHetero))!==false) {

	
	$nLnCount++;

	
	$sLnPop1 = trim($sLnPop1);
	$sLnPop2 = trim($sLnPop2);
	$sLnHetero = trim($sLnHetero);
	
	$arrFieldsPop1 = explode("\t", trim($sLnPop1));
	$arrFieldsPop2 = explode("\t", trim($sLnPop2));
	$arrFieldsHetero = explode("\t", trim($sLnHetero));
	
	$nFieldCountPop1 = count($arrFieldsPop1);
	//echo($nFieldCountPop1);
	if ($nLnCount == 0) { // parse header	
			for($i=0;$i<$nFieldCountPop1;$i++) {
		
			  $sHeaderPop1 = $arrFieldsPop1[$i];
			 
			  preg_match("|(\d+)\:(\d+)|",  trim( $sHeaderPop1 ), $arrScfld);
			  $nScfld = $arrScfld[1];
			  $nCoord = $arrScfld[2];
			  
			  array_push($arrCoordinates , [$nScfld, $nCoord]);
			  $arrFlatCoordinates[$nCoord] = 0;
			  //print_r($arrCoordinates);
			  //die();
			  //print_r($arrScfld);
			  //die();
			  if ($nScfld < $nScfldLimit) {
				array_push($arrMask , true);
			  }
			  else {
				array_push($arrMask , false);
				//echo( $nScfld." ");
			  }
			  
			  if ($arrFieldsPop2[$i] != $arrFieldsHetero[$i] || $arrFieldsPop1[$i] != $arrFieldsHetero[$i] || $arrFieldsPop2[$i] != $arrFieldsPop1[$i] )	{
				die("Headers don't match between the three input files at column $i");
			  }
	
			}
			
		echo(count($arrMask)." loci indicated in header".PHP_EOL);
		

		
		
	}
	
	
	
	
	if ($sLnPop1 == "" || $sLnPop2 == "" || $sLnHetero == "") continue;
	
	
	$nFieldCountPop1 = count($arrFieldsPop1);
	$nFieldCountPop2 = count($arrFieldsPop2);
	$nFieldCountHetero = count($arrFieldsHetero);
	
	if ($nFieldCountPop1!=$nFieldCountPop2 || $nFieldCountPop2 != $nFieldCountHetero || $nFieldCountPop1!=$nFieldCountHetero) {
		die("The number of fields on line $nLnCount differs between files: Pop1 $nFieldCountPop1 ; Pop2 $nFieldCountPop2 ; Hetero $nFieldCountHetero");
	}
	
	if ($arrFieldsPop1[0] != $arrFieldsPop2[0] || $arrFieldsPop2[0] != $arrFieldsHetero[0] || $arrFieldsPop1[0] != $arrFieldsHetero[0]) {
	
		die("Sample labels disagree among the three genotype files on line  $nLnCount. Pop1 ".$arrFieldsPop1[0]." ; Pop2 ".$arrFieldsPop2[0] ." ; Hetero ". $arrFieldsHetero[0]);
	}
	
	
	if (in_array($arrFieldsPop1[0], $arrExcludeList ) ) { // exclude it!
		continue;
	}
	
	$arrIndividual = array();
	
	for($i=1;$i<$nFieldCountPop1;$i++) {
		if (isset($arrMask[$i])) {
		
			if ($arrMask[$i]) {
				array_push( $arrIndividual , fnParseField($arrFieldsPop1[$i],$arrFieldsPop2[$i], $arrFieldsHetero[$i] ));	
			}
		}
		else {
			//echo($arrFieldsPop1[$i]);
		}
		
		$bIsNa = fnIsNa($arrFieldsPop1[$i],$arrFieldsPop2[$i], $arrFieldsHetero[$i] );

		if (!isset($arrExcludeSites[$i-1])) {
			$arrExcludeSites[$i-1] = false ;
		}
			
		if ($bIsNa && $bNoMissing) {
			$arrExcludeSites[$i-1] = true;
		}
	}
	
	if ( trim($arrFieldsPop1[0]) != "") {
		$sSampleName = str_replace("-", "", trim($arrFieldsPop1[0])); //remove all "-"
		//$arrMatrix[$sSampleName] = $arrIndividual;
	}
	
	echo("Assessing msg quality for $sSampleName ...\n");
	
		$nPrevScfld = -1;
		$nPrevCoord = 0;
		$nLoci = count($arrIndividual);
		$nBlockState = -2;
		$nBlockLen = 0;
		for ($i=0;$i<$nLoci;$i++) {
			$nMSGState = $arrIndividual[$i];
			
			$nCurrScfld = $arrCoordinates[$i][0];
			$nCurrCoord = $arrCoordinates[$i][1];
			
					
			if ($nCurrScfld != $nPrevScfld) {
				$nPrevCoord = 0;
				$nPrevScfld = $nCurrScfld; 
				continue;
			}
			
			if ($nBlockState !== $nMSGState ) {
				if ($nBlockLen!==0) {
					fwrite($arrOutFileHandlers[$nBlockState] , $nBlockLen.PHP_EOL);
					 $nBlockLen = 0;
				}
				$nBlockState = $nMSGState;
				continue;
			}
			
			$nBlockLen += $nCurrCoord- $nPrevCoord;
			$nPrevCoord = $nCurrCoord;

 
			
		}

	


	
	
	
	$nSampleCount++;

}








function fnParseField($nProbPop1, $nProbPop2, $nProbHetero) {
	global $nCutoffProb;
	if (strtoupper($nProbPop1)=="NA" || strtoupper($nProbPop2) == "NA" || strtoupper($nProbHetero) == "NA") {
		//echo("missing1");
		return -1;
	}
	
	if (((float)$nProbPop1) >= $nCutoffProb) {
		return 0;
	}
	
	if (((float)$nProbPop2) >= $nCutoffProb) {
		return 2;
	}
	
	if (((float)$nProbHetero) >= $nCutoffProb) {
		return 1;
	}
	
	//echo("missing2");
	return -1; //missing
}

function fnIsNa($nProbPop1, $nProbPop2, $nProbHetero) {
	global $nCutoffProb;
	if (strtoupper($nProbPop1)=="NA" || strtoupper($nProbPop2) == "NA" || strtoupper($nProbHetero) == "NA") {
		//echo("missing1");
		return true;
	}
	else {
		return false;
	}
	
}

function fnStateToStr($nState) {

	switch($nState) {
		case -1 : return "0\t0\t";
		case 0	: return "1\t1\t";
		case 1	: return "1\t2\t";
		case 2	: return "2\t2\t";
		default: return "0\t0\t";
	}
}

function FilterNegatives($val) {
	return $val>=0;
}

function fnParseRawAncestry($sMSGSampleName, $arrFlatCoordinates) {
	global $sSimulationFolder, $arrStatesInAncestry,$arrStatesInMSG, $arrAncestryVals, $sPregFileStem, $sHap1FileEnding, $sHap2FileEnding, $nIndIndexOffset;
	
	preg_match($sPregFileStem , $sMSGSampleName , $arrMatches) ;
	if (count($arrMatches)!=2) {
		die("Cannot determine file stem from MSG sample name $sMSGSampleName\n");
	}
	
	$sHap1 = $sSimulationFolder."/".($arrMatches[1] + $nIndIndexOffset). $sHap1FileEnding;
	$sHap2 = $sSimulationFolder."/".($arrMatches[1]  + $nIndIndexOffset). $sHap2FileEnding;
	$hHap1 = fopen($sHap1 , "r") or die("Cannot open $sHap1 \n");
	$hHap2 = fopen($sHap2 , "r") or die("Cannot open $sHap2 \n");
	
	echo(fgets($hHap1));
	echo(fgets($hHap2));
	$arrRet = array();
	$nLocusCount = 1;
	while((($sHap1Char=fgetc($hHap1))!==false ) && (($sHap2Char=fgetc($hHap2))!==false) ) {
		
		

		
		if (trim($sHap1Char) == '') {
			continue;
		}
		
		$nLocusCount++;
		
		if (!array_key_exists($nLocusCount,$arrFlatCoordinates)) {
			continue;
		}
		
		$nHap1Anc = strtolower($sHap1Char);
		$nHap2Anc = strtolower($sHap2Char);
		
		$arrRet[$nLocusCount] = $arrAncestryVals[$nHap1Anc] + $arrAncestryVals[$nHap2Anc];
		
	}
	
	return $arrRet;
}

/*
function fnGetFastaSeq($sFile) {
	$hFile = fopen($sFile, "r");
	if (!$hFile) {
		die("Can't open $sFile\n ");
	}
	fgets($hFile);
	return trim(fgets($hFile));
}
*/


?>