<?php
ini_set ( "memory_limit", -1 );

$arrOpts = getopt("1:2:3:i:f:p:l:o:S:B:");

$sGenotypeFilePop1 = $arrOpts["1"]; 
$sGenotypeFilePop2 = $arrOpts["2"]; 
$sGenotypeFileHetero = $arrOpts["3"];
$sSimulationFolder = $arrOpts["i"];
$sFilterList = $arrOpts["f"]; 
$nCutoffProb = $arrOpts["p"]; 
$nScfldLimit = $arrOpts["l"]; 
$sOut= $arrOpts["o"];
$bMaleHemizygous = ($arrOpts["S"] == "yes")? true : false;
$sBarcodeFile = $arrOpts["B"];

//do not change below
$bDuplicate = false;
$nDuplicateTill = 1000000;  
$nSubSampleEvery = 1; 
$bNoMissing = false;
$sPregFileStem = "/indiv(\d+)\_/";
$sHap1FileEnding = "_ancestry_hap1.txt";
$sHap2FileEnding = "_ancestry_hap2.txt";
$nIndIndexOffset = 0;

$arrStatesInAncestry = array(0, 1 , 2);
$arrStatesInMSG= array(0, 1 , 2, -1);
$arrAncestryVals = array("b"=> 1, "m" => 0 );

$arrExcludeList = array("null");

$hGenotypeFilePop1 = fopen($sGenotypeFilePop1 , "r");
$hGenotypeFilePop2 = fopen($sGenotypeFilePop2 , "r");
$hGenotypeFileHetero = fopen($sGenotypeFileHetero , "r");
$hFilterList = fopen($sFilterList , "r");
$hBarcodeFile = fopen($sBarcodeFile , "r");
$hOut= fopen($sOut, "w");

$arrFilterList = array();

$bNoFilterList = false;

if ($hFilterList == false) {
	$bNoFilterList = true;
	echo("No filter list specified, will output all samples\n");
}
else {

	while(($sLn = fgets($hFilterList ))!==false) {

		array_push($arrFilterList , trim($sLn));

	}
}


$arrIndSex = array();
if ($hBarcodeFile == false) {
	die("No barcode file is provided. Please use -B to specify.\n");
}
else {

	while(($sLn = fgets($hBarcodeFile ))!==false) {
		$arrBarcodeFld = explode("\t", trim($sLn));
		$arrIndSex[$arrBarcodeFld[1]] = $arrBarcodeFld[3];

	}
}


$arrMatrix = array();
$arrMask = array();
$arrExcludeSites = array();
$arrCoordinates = array();
$arrFlatCoordinates = array();
$nLnCount = -1;
$nSampleCount = 0;
echo("Reading genotype file...\n");
$arrStateTransitionMatrix = array();

while(($sLnPop1 = fgets($hGenotypeFilePop1))!==false && ($sLnPop2 = fgets($hGenotypeFilePop2))!==false && ($sLnHetero = fgets($hGenotypeFileHetero))!==false) {

	
	$nLnCount++;
	
	if (($nLnCount - 1 )> $nDuplicateTill && $bDuplicate) {
		break;
	}
	
	$sLnPop1 = trim($sLnPop1);
	$sLnPop2 = trim($sLnPop2);
	$sLnHetero = trim($sLnHetero);
	
	$arrFieldsPop1 = explode("\t", trim($sLnPop1));
	$arrFieldsPop2 = explode("\t", trim($sLnPop2));
	$arrFieldsHetero = explode("\t", trim($sLnHetero));
	
	$nFieldCountPop1 = count($arrFieldsPop1);
	//echo($nFieldCountPop1);
	if ($nLnCount == 0) { // parse header	
			for($i=0;$i<$nFieldCountPop1;$i++) {
		
			  $sHeaderPop1 = $arrFieldsPop1[$i];
			 
			  preg_match("|(\d+)\:(\d+)|",  trim( $sHeaderPop1 ), $arrScfld);
			  $nScfld = $arrScfld[1];
			  $nCoord = $arrScfld[2];
			  
			  array_push($arrCoordinates , array($nScfld, $nCoord));
			  $arrFlatCoordinates[$nCoord] = 0;
			  //print_r($arrCoordinates);
			  //die();
			  //print_r($arrScfld);
			  //die();
			  if ($nScfld < $nScfldLimit) {
				array_push($arrMask , true);
			  }
			  else {
				array_push($arrMask , false);
				//echo( $nScfld." ");
			  }
			  
			  if ($arrFieldsPop2[$i] != $arrFieldsHetero[$i] || $arrFieldsPop1[$i] != $arrFieldsHetero[$i] || $arrFieldsPop2[$i] != $arrFieldsPop1[$i] )	{
				die("Headers don't match between the three input files at column $i");
			  }
	
			}
			
		echo(count($arrMask)." loci indicated in header".PHP_EOL);
		

		
		
		
		
		fwrite($hOut , "Sample\tBlockSize\t");
		foreach($arrStatesInAncestry as $sRealAncState) {
			foreach($arrStatesInMSG as $sInferredState) {
				$arrStateTransitionMatrix[$sRealAncState.">".$sInferredState] = 0;
				fwrite($hOut , "\t".$sRealAncState.">".$sInferredState);
			}
		}
		fwrite($hOut , PHP_EOL);
		
		
		continue;
	}
	
	
	
	
	if ($sLnPop1 == "" || $sLnPop2 == "" || $sLnHetero == "") continue;
	
	
	$nFieldCountPop1 = count($arrFieldsPop1);
	$nFieldCountPop2 = count($arrFieldsPop2);
	$nFieldCountHetero = count($arrFieldsHetero);
	
	if ($nFieldCountPop1!=$nFieldCountPop2 || $nFieldCountPop2 != $nFieldCountHetero || $nFieldCountPop1!=$nFieldCountHetero) {
		die("The number of fields on line $nLnCount differs between files: Pop1 $nFieldCountPop1 ; Pop2 $nFieldCountPop2 ; Hetero $nFieldCountHetero");
	}
	
	if ($arrFieldsPop1[0] != $arrFieldsPop2[0] || $arrFieldsPop2[0] != $arrFieldsHetero[0] || $arrFieldsPop1[0] != $arrFieldsHetero[0]) {
	
		die("Sample labels disagree among the three genotype files on line  $nLnCount. Pop1 ".$arrFieldsPop1[0]." ; Pop2 ".$arrFieldsPop2[0] ." ; Hetero ". $arrFieldsHetero[0]);
	}
	
	
	if (in_array($arrFieldsPop1[0], $arrExcludeList ) ) { // exclude it!
		continue;
	}
	
	$arrIndividual = array();
	
	for($i=1;$i<$nFieldCountPop1;$i++) {
		if (isset($arrMask[$i])) {
		
			if ($arrMask[$i]) {
				array_push( $arrIndividual , fnParseField($arrFieldsPop1[$i],$arrFieldsPop2[$i], $arrFieldsHetero[$i] ));	
			}
		}
		else {
			//echo($arrFieldsPop1[$i]);
		}
		
		$bIsNa = fnIsNa($arrFieldsPop1[$i],$arrFieldsPop2[$i], $arrFieldsHetero[$i] );

		if (!isset($arrExcludeSites[$i-1])) {
			$arrExcludeSites[$i-1] = false ;
		}
			
		if ($bIsNa && $bNoMissing) {
			$arrExcludeSites[$i-1] = true;
		}
	}
	
	if ( trim($arrFieldsPop1[0]) != "") {
		$sSampleName = str_replace("-", "", trim($arrFieldsPop1[0])); //remove all "-"
		//$arrMatrix[$sSampleName] = $arrIndividual;
	}
	
	echo("Assessing msg quality for $sSampleName ...\n");
	
		foreach($arrStatesInAncestry as $sRealAncState) {
			foreach($arrStatesInMSG as $sInferredState) {
				$arrStateTransitionMatrix[$sRealAncState.">".$sInferredState] = 0;
			}
		}
					//parse in raw ancestry files:
		$arrRawAncestry = fnParseRawAncestry($sSampleName, $arrFlatCoordinates);
		echo("Real ancestry parsed in ".count($arrRawAncestry)." loci\n");
		$nPrevScfld = -1;
		$nPrevCoord = -1 - $nSubSampleEvery;
		$nThresholdCoord = $nPrevCoord + $nSubSampleEvery;
		$nAncestrySeqLen = max(array_keys($arrRawAncestry));
		$nLoci = count($arrIndividual);
		$nBlockStartCoord = -1;
		$nPrevAncestry = -2;
		
		for ($i=0;$i<$nLoci;$i++) {
			$nMSGState = $arrIndividual[$i];
			
			$nCurrScfld = $arrCoordinates[$i][0];
			$nCurrCoord = $arrCoordinates[$i][1];
			
			if ($nCurrCoord > $nAncestrySeqLen ) {
				die("Requested coordinate ($nCurrCoord) exceeds length of ancestry file ($nAncestrySeqLen).".PHP_EOL);
			}
			
			$nRealState = $arrRawAncestry[$nCurrCoord];
			
			if ($nCurrScfld != $nPrevScfld) {
				$nPrevCoord = -1 - $nSubSampleEvery;
				$nThresholdCoord = $nPrevCoord + $nSubSampleEvery;
				$nPrevScfld = $nCurrScfld; 
				$nBlockStartCoord = -1;
				$nPrevAncestry = -2;
			}
			
			if ( $nThresholdCoord <= $nCurrCoord) {
			
			}
			else {
				continue; //skip
			}
			
			
			
			if ($arrExcludeSites[$i]) {
				continue;
			}
			
			if (($nPrevAncestry  != $nRealState) &&  ($nPrevCoord >= 0)) { // ancestry switched, calculate previous block size and output stats
				
				fwrite($hOut , $sSampleName . "\t". ( $nPrevCoord - $nBlockStartCoord)."\t" . implode("\t", $arrStateTransitionMatrix));
				fwrite($hOut , PHP_EOL);
				//clear matrix
				foreach($arrStatesInAncestry as $sRealAncState) {
					foreach($arrStatesInMSG as $sInferredState) {
						$arrStateTransitionMatrix[$sRealAncState.">".$sInferredState] = 0;
					}
				}
				
				$nBlockStartCoord = $nCurrCoord;
				$nPrevAncestry  = $nRealState;
			}
			
			$nPrevCoord = $nCurrCoord;
			$nThresholdCoord = $nPrevCoord + $nSubSampleEvery;

			$arrStateTransitionMatrix[$nRealState.">".$nMSGState] += 1;
 
			
		}
		
		fwrite($hOut , $sSampleName . "\t". ( $nPrevCoord - $nBlockStartCoord)."\t". implode("\t", $arrStateTransitionMatrix));
		fwrite($hOut , PHP_EOL);
	


	
	
	
	$nSampleCount++;

}








function fnParseField($nProbPop1, $nProbPop2, $nProbHetero) {
	global $nCutoffProb;
	if (strtoupper($nProbPop1)=="NA" || strtoupper($nProbPop2) == "NA" || strtoupper($nProbHetero) == "NA") {
		//echo("missing1");
		return -1;
	}
	
	if (((float)$nProbPop1) >= $nCutoffProb) {
		return 0;
	}
	
	if (((float)$nProbPop2) >= $nCutoffProb) {
		return 2;
	}
	
	if (((float)$nProbHetero) >= $nCutoffProb) {
		return 1;
	}
	
	//echo("missing2");
	return -1; //missing
}

function fnIsNa($nProbPop1, $nProbPop2, $nProbHetero) {
	global $nCutoffProb;
	if (strtoupper($nProbPop1)=="NA" || strtoupper($nProbPop2) == "NA" || strtoupper($nProbHetero) == "NA") {
		//echo("missing1");
		return true;
	}
	else {
		return false;
	}
	
}

function fnStateToStr($nState) {

	switch($nState) {
		case -1 : return "0\t0\t";
		case 0	: return "1\t1\t";
		case 1	: return "1\t2\t";
		case 2	: return "2\t2\t";
		default: return "0\t0\t";
	}
}

function FilterNegatives($val) {
	return $val>=0;
}

function fnParseRawAncestry($sMSGSampleName, $arrFlatCoordinates) {
	global $sSimulationFolder, $arrStatesInAncestry,$arrStatesInMSG, $arrAncestryVals, $sPregFileStem, $sHap1FileEnding, $sHap2FileEnding, $nIndIndexOffset , $arrIndSex , $bMaleHemizygous;
	
	preg_match($sPregFileStem , $sMSGSampleName , $arrMatches) ;
	if (count($arrMatches)!=2) {
		die("Cannot determine file stem from MSG sample name $sMSGSampleName\n");
	}
	
	
	$nIndID = $arrMatches[1];
	if (!array_key_exists($nIndID ,$arrIndSex )) {
		die("Error: sex of individual  $sMSGSampleName not found in the barcode file.\n");
	}
	

	$sHap1 = $sSimulationFolder."/".($arrMatches[1] + $nIndIndexOffset). $sHap1FileEnding;
	$sHap2 = $sSimulationFolder."/".($arrMatches[1]  + $nIndIndexOffset). $sHap2FileEnding;
	
	$hHap1 = fopen($sHap1 , "r") or die("Cannot open $sHap1 \n");
	$hHap2 = fopen($sHap2 , "r") or die("Cannot open $sHap2 \n");
	
	$bIgnoreHap2 = false; //if hemizygous, ignore hap2.
	if ( ($arrIndSex[$nIndID] == "male") && $bMaleHemizygous) { //only read in haplotype 1.
		$bIgnoreHap2 = true;
		echo("This is a male, treat it hemizygous and only use haplotype 1.\n");
	}
	
	echo(fgets($hHap1));
	echo(fgets($hHap2));
	$arrRet = array();
	$nLocusCount = 1;
	while((($sHap1Char=fgetc($hHap1))!==false ) && (($sHap2Char=fgetc($hHap2))!==false) ) {
		


		
		if (trim($sHap1Char) == '') {
			continue;
		}
		
		if ($bIgnoreHap2) { // if ignore hap2, then hap2 = hap1.
			$sHap2Char = $sHap1Char;
		}
		
		$nLocusCount++;
		
		if (!array_key_exists($nLocusCount,$arrFlatCoordinates)) {
			continue;
		}
		
		$nHap1Anc = strtolower($sHap1Char);
		$nHap2Anc = strtolower($sHap2Char);
		
		$arrRet[$nLocusCount] = $arrAncestryVals[$nHap1Anc] + $arrAncestryVals[$nHap2Anc];
		
	}
	
	return $arrRet;
}

/*
function fnGetFastaSeq($sFile) {
	$hFile = fopen($sFile, "r");
	if (!$hFile) {
		die("Can't open $sFile\n ");
	}
	fgets($hFile);
	return trim(fgets($hFile));
}
*/


?>