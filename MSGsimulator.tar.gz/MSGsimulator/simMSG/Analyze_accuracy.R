args<-commandArgs(TRUE)
range1<-as.numeric(args[1])
range2<-as.numeric(args[2])
range3<-as.numeric(args[3])
range4<-as.numeric(args[4])
range5<-as.numeric(args[5])
range6<-as.numeric(args[6])
Mb<-as.numeric(args[7])/1e6
priors1<-as.numeric(args[8])
priors2<-as.numeric(args[9])
priors3<-as.numeric(args[10])

#READ IN RESULTS OF FIRST ACCURACY ANALYSIS
accuracy<-read.table(file="accuracy.txt",head=TRUE)
length<-length(accuracy$Sample)

#READ IN RESULTS OF BLOCK LENGTH ACCURACY ANALYSIS
accuracybp<-read.table(file="genomelen_acc.txt",head=TRUE)
lengthbp<-length(accuracybp$Sample)

#DETERMINE NUMBER OF MARKERS
genotypes<-read.table(file="ancestry-probs-par1.tsv",sep="\t",head=TRUE)
num_markers<-length(genotypes[1,])

#READ IN INDIVIDUAL ANCESTRIES
ancestry<-read.table(file="individual_priors",sep="\t",head=TRUE)
par1<-mean(ancestry$prop_par1)^2
par1par2<-2*mean(ancestry$prop_par1)*mean(ancestry$prop_par2)
par2<-mean(ancestry$prop_par2)^2

#INITIALIZE 
lengths_accurate_calls<-{}; lengths_inaccurate_calls<-{}; lengths_missing_calls<-{}; total_accurate_calls<-{};
total_inaccurate_calls<-{}; total_missing_calls<-{}; par1_accurate_calls<-{}; par2_accurate_calls<-{}; par1_inaccurate_calls<-{};
par2_inaccurate_calls<-{}; par1_missing_calls<-{}; par2_missing_calls<-{}; par1_accurate_calls_hets<-{}; par2_accurate_calls_hets<-{};
par1_missing_calls_hets<-{}; par2_missing_calls_hets<-{}; par1_inaccurate_calls_hets<-{}; par2_inaccurate_calls_hets<-{}; size1_accurate_calls<-{}; 
size1_inaccurate_calls<-{}; size1_missing_calls<-{}; size2_accurate_calls<-{}; size2_inaccurate_calls<-{}; size2_missing_calls<-{}; 
size3_accurate_calls<-{}; size3_inaccurate_calls<-{}; size3_missing_calls<-{}; homo_opposite<-{}; hetero_homo<-{}; homo_hetero<-{}; indiv_accuracy<-{};
current_indiv_accuracy<-{}; current_indiv_inaccuracy<-{}; current_indiv_missing<-{}

indiv<-0

for (x in 1:length){
accurate_calls<-accuracy[x,3]+accuracy[x,8]+accuracy[x,13]
missing_calls<- accuracy[x,6]+accuracy[x,10]+accuracy[x,14]
incorrect_calls<- accuracy[x,4]+accuracy[x,5]+accuracy[x,7]+accuracy[x,9]+ accuracy[x,11]+accuracy[x,12]

homo_opposite<-c(homo_opposite,accuracy[x,5]+accuracy[x,11])
hetero_homo<-c(hetero_homo,accuracy[x,7]+accuracy[x,9])
homo_hetero<-c(homo_hetero,accuracy[x,4]+accuracy[x,12])

indiv_prev=indiv
indiv=as.numeric(accuracy[x,1])
blocksize<-accuracy[x,2]

	if ((blocksize>range1)&(blocksize<range2)){
	size1_accurate_calls<-c(size1_accurate_calls,accurate_calls)
	size1_inaccurate_calls<-c(size1_inaccurate_calls,incorrect_calls)
	size1_missing_calls<-c(size1_missing_calls, missing_calls)
	}
	else if ((blocksize>range3)&(blocksize<range4)){
        size2_accurate_calls<-c(size2_accurate_calls,accurate_calls)
        size2_inaccurate_calls<-c(size2_inaccurate_calls,incorrect_calls)
        size2_missing_calls<-c(size2_missing_calls, missing_calls)
	}
	else if	((blocksize>range5)&(blocksize<range6)){
	size3_accurate_calls<-c(size3_accurate_calls,accurate_calls)
	size3_inaccurate_calls<-c(size3_inaccurate_calls,incorrect_calls)
	size3_missing_calls<-c(size3_missing_calls, missing_calls)
        }

if ((accurate_calls+incorrect_calls)>0){
if(accurate_calls>=1){
	lengths_accurate_calls<-c(lengths_accurate_calls, blocksize)
	}

if(incorrect_calls>=1){
	lengths_inaccurate_calls<-c(lengths_inaccurate_calls, blocksize)
	}
}

if((accurate_calls+incorrect_calls)==0){
	lengths_missing_calls<-c(lengths_missing_calls,blocksize)
}

total_accurate_calls<-c(total_accurate_calls,accurate_calls)
total_inaccurate_calls<-c(total_inaccurate_calls,incorrect_calls)
total_missing_calls<-c(total_missing_calls,missing_calls)


if(indiv == indiv_prev){
current_indiv_accuracy<-c(current_indiv_accuracy,total_accurate_calls)
current_indiv_inaccuracy<-c(current_indiv_inaccuracy,total_inaccurate_calls)
current_indiv_missing<-c(current_indiv_missing,total_missing_calls)
} else if(indiv != indiv_prev){
indiv_accuracy<-c(sum(current_indiv_accuracy)/(sum(current_indiv_accuracy)+sum(current_indiv_inaccuracy)+sum(current_indiv_missing)),indiv_accuracy)
current_indiv_accuracy<-{}
current_indiv_inaccuracy<-{}
current_indiv_missing<-{}
}



par1_accurate_calls<-c(par1_accurate_calls,accuracy[x,3])
par2_accurate_calls<-c(par2_accurate_calls,accuracy[x,13])
par1_missing_calls<-c(par1_missing_calls,accuracy[x,6])
par2_missing_calls<-c(par2_missing_calls,accuracy[x,14])
par1_inaccurate_calls<-c(par1_inaccurate_calls,accuracy[x,4]+accuracy[x,5])
par2_inaccurate_calls<-c(par2_inaccurate_calls,accuracy[x,11]+accuracy[x,12])

par1_accurate_calls_hets<-c(par1_accurate_calls_hets,accuracy[x,3]+0.5*accuracy[x,8])
par2_accurate_calls_hets<-c(par2_accurate_calls_hets,accuracy[x,13]+0.5*accuracy[x,8])
par1_missing_calls_hets<-c(par1_missing_calls_hets,accuracy[x,6]+0.5*accuracy[x,10])
par2_missing_calls_hets<-c(par2_missing_calls_hets,accuracy[x,14]+0.5*accuracy[x,10])
par1_inaccurate_calls_hets<-c(par1_inaccurate_calls_hets,accuracy[x,4]+accuracy[x,5]+0.5*accuracy[x,7])
par2_inaccurate_calls_hets<-c(par2_inaccurate_calls_hets,accuracy[x,11]+accuracy[x,12]+0.5*accuracy[x,12])

}#for all x

inaccurate_blocks=0
total_blocks=0
for (x in 1:length){
    total<-accuracy[x,3]+accuracy[x,8]+accuracy[x,13]+accuracy[x,4]+accuracy[x,5]+accuracy[x,7]+accuracy[x,9]+ accuracy[x,11]+accuracy[x,12]
    if (total>0){
    accurate<-(accuracy[x,3]+accuracy[x,8]+accuracy[x,13])/total
    inaccurate<-(accuracy[x,4]+accuracy[x,5]+accuracy[x,7]+accuracy[x,9]+ accuracy[x,11]+accuracy[x,12])/total
    total_blocks=total_blocks+1;
if(inaccurate>0.01){
inaccurate_blocks=inaccurate_blocks+1
}
    }
}


indiv_accuracy<-c(sum(current_indiv_accuracy)/(sum(current_indiv_accuracy)+sum(current_indiv_inaccuracy)+sum(current_indiv_missing)),indiv_accuracy)

average_length_accurate<-mean(lengths_accurate_calls)
average_length_inaccurate<-mean(lengths_inaccurate_calls)


proportions_aims_accurate<-sum(total_accurate_calls)/(sum(total_inaccurate_calls)+sum(total_accurate_calls)+sum(total_missing_calls))
proportions_aims_inaccurate<-sum(total_inaccurate_calls)/(sum(total_inaccurate_calls)+sum(total_accurate_calls)+sum(total_missing_calls))
proportions_aims_accurate_excluding_ambiguous<-sum(total_accurate_calls)/(sum(total_inaccurate_calls)+sum(total_accurate_calls))

proportion_blocks_inaccurate<-inaccurate_blocks/total_blocks

proportions_aims_accurate_size1<-sum(size1_accurate_calls)/(sum(size1_accurate_calls)+sum(size1_inaccurate_calls)+sum(size1_missing_calls))
proportions_aims_accurate_size2<-sum(size2_accurate_calls)/(sum(size2_accurate_calls)+sum(size2_inaccurate_calls)+sum(size2_missing_calls))
proportions_aims_accurate_size3<-sum(size3_accurate_calls)/(sum(size3_accurate_calls)+sum(size3_inaccurate_calls)+sum(size3_missing_calls))

proportion_inaccurate_homo_opposite<-sum(homo_opposite)/(sum(homo_opposite)+sum(hetero_homo)+sum(homo_hetero))
proportion_inaccurate_hetero_homo<-sum(hetero_homo)/(sum(homo_opposite)+sum(hetero_homo)+sum(homo_hetero))
proportion_inaccurate_homo_hetero<-sum(homo_hetero)/(sum(homo_opposite)+sum(hetero_homo)+sum(homo_hetero))

proportion_par1_accurate<-sum(par1_accurate_calls)/(sum(par1_accurate_calls)+sum(par1_missing_calls)+sum(par1_inaccurate_calls))
proportion_par2_accurate<-sum(par2_accurate_calls)/(sum(par2_accurate_calls)+sum(par2_missing_calls)+sum(par2_inaccurate_calls))

proportion_par1_accurate_hets<-sum(par1_accurate_calls_hets)/(sum(par1_accurate_calls_hets)+sum(par1_missing_calls_hets)+sum(par1_inaccurate_calls_hets))
proportion_par2_accurate_hets<-sum(par2_accurate_calls_hets)/(sum(par2_accurate_calls_hets)+sum(par2_missing_calls_hets)+sum(par2_inaccurate_calls_hets))

##############################################
###Now analyze accuracy by block length#######
##############################################

indivbp<-1
accurate_length<-{}
accurate_length_sums<-{}
total_length<-{}
indivbp_accuracy<-{}

for (x in 1:lengthbp){

indiv_prevbp=indivbp
indivbp=as.numeric(accuracybp[x,1])

if(indivbp == indiv_prevbp){

if(accuracybp[x,5]==1){
accurate_length<-c(accurate_length,accuracybp[x,2])
total_length<-c(total_length,accuracybp[x,2])
} else{
total_length<-c(total_length,accuracybp[x,2])
}

} else if(indivbp != indiv_prevbp){
indivbp_accuracy<-c(sum(accurate_length)/(sum(total_length)),indivbp_accuracy)
accurate_length_sums<-c(sum(accurate_length),accurate_length_sums)
accurate_length<-{}
total_length<-{}
}

}

##############################################
#####Write out results########################
##############################################

col1<-rbind(signif(proportions_aims_accurate,3),signif(proportion_par1_accurate_hets,3), signif(proportion_par2_accurate_hets,3),signif(proportion_par1_accurate,3),signif(proportion_par2_accurate,3),signif(mean(indivbp_accuracy,na.rm=TRUE),3),num_markers,signif(proportion_blocks_inaccurate,3),round(average_length_accurate),round(average_length_inaccurate),signif(proportions_aims_accurate_size1,3),signif(proportions_aims_accurate_size2,3),signif(proportions_aims_accurate_size3,3),signif(proportion_inaccurate_homo_opposite,3),signif(proportion_inaccurate_hetero_homo,3),signif(proportion_inaccurate_homo_hetero,3),par1,par1par2,par2)
col2<-rbind("",paste("(",round(sum(c(par1_accurate_calls_hets,par1_missing_calls_hets,par1_inaccurate_calls_hets))/indiv),"markers/individual )",sep=" "),paste("(",round(sum(c(par2_accurate_calls_hets,par2_missing_calls_hets,par2_inaccurate_calls_hets))/indiv),"markers/individual )",sep=" "),paste("(",round(sum(c(par1_accurate_calls,par1_missing_calls,par1_inaccurate_calls))/indiv),"markers/individual )",sep=" "),paste("(",round(sum(c(par2_accurate_calls,par2_missing_calls,par2_inaccurate_calls))/indiv),"markers/individual )",sep=" "),paste(" (",round(mean(accurate_length_sums)),"bp/individual )",sep=" "),paste("(",num_markers/Mb,"markers/Mb )",sep=" "),paste("(",inaccurate_blocks,"blocks )",sep=" "),paste("(",length(lengths_accurate_calls),"blocks )",sep=" "),paste("(",length(lengths_inaccurate_calls),"blocks )",sep=" "),paste("(",length(c(size1_accurate_calls,size1_inaccurate_calls,size1_missing_calls)),"blocks )",sep=" "),paste("(",length(c(size2_accurate_calls,size2_inaccurate_calls,size2_missing_calls)),"blocks )",sep=" "),paste("(",length(c(size3_accurate_calls,size3_inaccurate_calls,size3_missing_calls)),"blocks )",sep=" "),paste("(",length(subset(homo_opposite,homo_opposite>0)),"markers )",sep=" "),paste("(",length(subset(hetero_homo,hetero_homo>0)),"markers )",sep=" "),paste("(",length(subset(homo_hetero,homo_hetero>0)),"markers )",sep=" "),paste("(",priors1,"expected )",sep=" "),paste("(",priors2,"expected )",sep=" "),paste("(",priors3,"expected )",sep=" "))

#print(col1)
#print(col2)

write.table(cbind(col1,col2),file="Simulation_results_summary.txt",row.names=c("Proportion AIMs accurate","Parent 1 accuracy by AIM","Parent 2 accuracy by AIM", "Parent 1 accuracy by AIM in homozygous regions","Parent 2 accuracy by AIM in homozygous regions","Proportion of basepairs accurately genotyped","Number of AIMs sampled","Proportion of ancestry tracts >1% inaccurate","Average block length accurate","Average length of blocks with inaccurate calls", paste("blocksize(bp):",range1,"-",range2),paste("blocksize(bp):",range3,"-",range4), paste("blocksize(bp):",range5,"-",range6),"Proportion incorrect calls homozygous opposite","Proportion incorrect calls heterozygous to homozygous","Proportion incorrect calls homozygous to heterozygous","Estimated priors par1","Estimated priors par1par2", "Estimated priors par2"),sep="\t",col.names=FALSE,append=TRUE)

pdf("accuracy_distribution.pdf")
low<-min(indiv_accuracy,na.rm=TRUE)
high<-max(indiv_accuracy,na.rm=TRUE)
hist(indiv_accuracy,xlab="Proportion Accurate Calls",ylab="Frequency",cex.lab=1.3,cex.axis=1.2,xlim=c(low-0.05,high+0.05),col="gray")
dev.off()

pdf("ancestry_distribution.pdf")
low_ancestry<-min(ancestry$prop_par1,na.rm=TRUE)
high_ancestry<-max(ancestry$prop_par1,na.rm=TRUE)
hist(ancestry$prop_par1, xlab="Proportion Parent 1", ylab="Frequency",cex.lab=1.3,cex.axis=1.2, xlim=c(low_ancestry-0.1,high_ancestry+0.1),col="gray")
dev.off()