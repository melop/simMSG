#!perl

# generates a priors file from two .tsv files 
# usage
# perl parsetsv_priors.pl infilepar1 infilepar2 confidence > outfile
# confidence is the user-specified posterior probability required to call a locus for a particular ancestry

if (@ARGV<1){
	print "\nusage: perl parsetsv_priors.pl infilepar1 infilepar2 confidence > outfile\n\n"; exit;
}

my $infile = shift(@ARGV); chomp $infile;
open IN, $infile or die "wrong format for in1 infile\n";
my $infile2=shift(@ARGV); chomp $infile2;
open IN2, $infile2 or die "wrong format for in2 infile\n";

my $confidence1=shift(@ARGV);

my $na=NA;
my $par1count=0;
my $par2count=0;
my $par1=0;
my $par2=0;
my $confidence2=1-$confidence1;

print "id\tprop_par1\tprop_par2\n";

my $junk1=<IN>; chomp $junk1;
my $junk2=<IN2>; chomp $junk2;

while ((my $line = <IN>) && (my $line2=<IN2>)){
    chomp $line; chomp $line2;
    my @fields1 = split(/\t/, $line); #par1 genotypes
    my @fields2=split(/\t/,$line2); #par2 genotypes
    

    for my $i (1 .. scalar(@fields1)-1){
	if (($fields1[$i]>= $confidence1) & ($fields2[$i]<= $confidence2)){$par1count++;}
	elsif (($fields2[$i]>= $confidence1) & ($fields1[$i]<=$confidence2)){$par2count++}
	elsif ($fields1[$i]+$fields2[$i] <= $confidence2 ){$par1count=$par1count+.5;$par2count=$par2count+.5;}   
    	else{$genotype="$na";}
      } # for all markers for one individual

    if (($par1count > 0) or ($par2count > 0)){
    $par1=($par1count/($par1count+$par2count));
    $par2=($par2count/($par1count+$par2count));
    } 
    else {$par1="$na"; $par2="$na";}
    #if it is 100% par1 or par2 or all markers are missing
    
    my $indiv=$fields1[0];

    print "$indiv\t$par1\t$par2\n";
    $par1count=0; $par2count=0; 
    #reset the counter for each individual
} # while the infile has lines in it

