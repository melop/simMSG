#perl! -w

my $infile_stem1="parent1_chr1_poly.txt";
my $infile_stem2="parent2_chr1_poly.txt";
my $infile_stem3="parent1_chr2_poly.txt";
my $infile_stem4="parent2_chr2_poly.txt";
my $infile_number=shift(@ARGV); chomp $infile_number;

chdir "hybrid_genomes" or die "can't accesss hybrid genomes folder";

my %polymorphism=();
my @all_polymorphisms = ();
my $site=0;

open OUT, ">polymorphic_sites.insnp";

for $i (0..$infile_number-1){

    my $current_infile1="$i"."_"."$infile_stem1";
    open IN, $current_infile1 or die "cannot open $current_infile1\n";

    while (my $line=<IN>){

	my @elements=split(/\t/,$line);
	$site=$elements[1];

	if (! $polymorphism{$site}){
	push(@all_polymorphisms,$site);
	$polymorphism{$site}=1;
	}

    }#while lines in current infile

    my $current_infile2="$i"."_"."$infile_stem2";
    open IN2, $current_infile2 or die "cannot open $current_infile2\n";

    while (my $line2=<IN2>){

        my @elements2=split(/\t/,$line2);
        $site=$elements2[1];

        if (! $polymorphism{$site}){
	    push(@all_polymorphisms,$site);
	    $polymorphism{$site}=1;
        }

    }#while lines in current infile                                                                                                               
    my $current_infile3="$i"."_"."$infile_stem3";
    open IN3, $current_infile3 or die "cannot open $current_infile3\n";

    while (my $line3=<IN3>){

        my @elements3=split(/\t/,$line3);
        $site=$elements3[1];

        if (! $polymorphism{$site}){
            push(@all_polymorphisms,$site);
            $polymorphism{$site}=1;
        }

    }#while lines in current infile                                                                                                             
         
    my $current_infile4="$i"."_"."$infile_stem4";
    open IN4, $current_infile4 or die "cannot open $current_infile4\n";

    while (my $line4=<IN4>){

        my @elements4=split(/\t/,$line4);
	$site=$elements4[1];

	if (! $polymorphism{$site}){
            push(@all_polymorphisms,$site);
            $polymorphism{$site}=1;
        }

    }#while lines in current infile                                                                                                               



} #for all infiles

#print scalar(@all_polymorphisms),"\n";

#now that the set of polymorphisms have been identified, generate an insnp file for them

my @sorted_polymorphisms = sort {$a <=> $b} @all_polymorphisms;

for $j (0..scalar(@sorted_polymorphisms)-1){

    my $current_poly=$sorted_polymorphisms[$j]+1;
    
    print OUT "focalchrom1\t$current_poly\tX\tN\n";


}
