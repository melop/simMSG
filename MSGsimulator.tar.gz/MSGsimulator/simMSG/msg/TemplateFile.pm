package TemplateFile;
use strict;
use warnings;
use Exporter;

our @EXPORT=qw( UseTemplate );

sub WriteWithTemplate {
	my($sTemplate, $phVars, $sOutfile) = @_;
	open hTmpl, $sTemplate or die "Couldn't open file: $sTemplate"; 
	my $sTmpContent = join("", <hTmpl>); 
	close hTmpl;

	while (my($sKey, $sVal) = each %$phVars) {
    		$sTmpContent =~ s/\%$sKey\%/$sVal/g;
    	}

	open hOut, ">$sOutfile" or die "Couldn't open file: $sOutfile"; 
	print hOut $sTmpContent;
	close hOut
}

sub trim {
    (my $s = $_[0]) =~ s/^\s+|\s+$//g;
    return $s;        
}


sub GetLastLine {
	my($sIn) =@_;
	my @arrLns = split(/\n/, $sIn);
	for(my $i=$#arrLns - 1; $i>=0; $i--) {
		if (trim($arrLns[$i]) ne '') {
			return trim($arrLns[$i]);
		}
	}

	return '';
}
