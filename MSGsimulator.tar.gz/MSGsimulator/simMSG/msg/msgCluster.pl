#!/usr/bin/perl -w
use strict;
use lib qw(./msg .);
use Utils;
use IPC::Open2;
use Cwd;
use Cwd 'abs_path';
use TemplateFile;
use File::Basename;
use Data::Dumper;

my $sSriptDir = dirname(abs_path($0));

print "\nMSG\n";
print "\nScript directory: $sSriptDir\n";

my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
printf "%4d-%02d-%02d %02d:%02d:%02d\n\n", $year+1900,$mon+1,$mday,$hour,$min,$sec;

### Make sure all required dependencies are installed
&Utils::test_dependencies();
if ($? != 0) { exit(1); }

### Default parameters
### All of these parameters are required
my %default_params = (
        barcodes       => 'NULL',
        re_cutter      => 'MseI',
        linker_system  => 'Dros_SR_vII',
        reads          => 'NULL',
        parent1        => 'NULL',
        parent2        => 'NULL',
        chroms         => 'all',
        sexchroms      => 'X',
        chroms2plot    => 'all',
        deltapar1      => '.01',
        deltapar2      => '.01',
        recRate        => '0',
        rfac		      => '0.00001',
        thinfac	      => '1',
        difffac	      => '.01',
        priors         => '0,.5,.5',
        bwaindex1      => 'bwtsw',
        bwaindex2      => 'bwtsw',
        pnathresh      => '0.03',
        cluster        => '1',
        threads        => '8',
        theta        => '1',
        addl_qsub_option_for_exclusive_node => '',
        addl_qsub_option_for_pe => '',
        custom_qsub_options_for_all_cmds => '',
        bwa_alg => 'aln',
        bwa_threads => '1',
        use_stampy => '0',
        stampy_premap_w_bwa => '1',
        stampy_pseudo_threads => '0',
        quality_trim_reads_thresh => '0',
        quality_trim_reads_consec => '30',
        indiv_stampy_substitution_rate => '0.001',
        indiv_mapq_filter => '0',
        index_file => '',
        index_barcodes => '',
        email_host => '',
        notify_emails => '',
        debug => '0',
        gff_thresh_conf => '.95',
        new_parser => '0',
        new_parser_offset => '0',
        new_parser_filter_out_seq => '',
        pepthresh => '0.5',
        one_site_per_contig => '0',
		walltime1 => '01:00:00',
        walltime2 => '01:00:00',
        walltime3 => '02:00:00',
        barcodes_per_job => 4,
        msgRun1 => 1,           # Set to 0 to skip.
        nodes1 => 1,
        ppn1 => 1,
        msgRun2 => 1,           # Set to 0 to skip.
        nodes2 => 1,
        ppn2 => 1,
        msgRun3 => 1,           # Set to 0 to skip.
        nodes3 => 1,
        ppn3 => 1,
        mem3 => 0,              # If 0, then mem keyword not used.
    );


my $params = Utils::parse_config('msg.cfg', \%default_params);
Utils::validate_config($params, qw( barcodes reads parent1 parent2 ));
my %params = %$params;

print "==============MSG Parsed parameters ================\n";
print Dumper($params);
print "==============MSG Parsed parameters ================\n";
### check if all the desired chroms are found in both parental files
### report their lengths also
my %par1_reads = &Utils::readFasta($params{'parent1'}, 1);
my %par2_reads = &Utils::readFasta($params{'parent2'}, 1);
my @chroms ;
if( $params{'chroms'} eq 'all') { 
	@chroms = keys %par1_reads ; 
} else { @chroms = split(/,/,$params{'chroms'}); }

my $numcontigs = scalar(@chroms) ;

open (OUT,'>msg.chrLengths') || die "ERROR (msgCluster): Can't create msg.chrLengths: $!\n";
print OUT "chr,length\n";
foreach my $chr (sort @chroms) { print OUT "$chr,$par1_reads{$chr}\n"; } 
close OUT;

####################################################################################
### Parsing

if ($params{'msgRun1'}) {
    my $sScriptBody = "";
    #open (OUT,">msgRun1.$$.sh");
    #print OUT "#!/bin/bash\npwd\n/bin/hostname\n/bin/date\n" .
    $sScriptBody .=    'perl msg/msg.pl ' .
        ' --barcodes ' . $params{'barcodes'} .
        ' --re_cutter ' . $params{'re_cutter'} .
        ' --linker_system ' . $params{'linker_system'} .
        ' --reads ' . $params{'reads'} . 
        ' --bwaindex1 ' . $params{'bwaindex1'} .
        ' --bwaindex2 ' . $params{'bwaindex2'} .
        ' --bwa_alg ' . $params{'bwa_alg'} .
        ' --bwa_threads ' . $params{'bwa_threads'} .
        ' --use_stampy ' . $params{'use_stampy'} .
        ' --stampy_premap_w_bwa ' . $params{'stampy_premap_w_bwa'} .
        ' --parent1 ' . $params{'parent1'} .
        ' --parent2 ' . $params{'parent2'} .
        ' --indiv_stampy_substitution_rate ' . $params{'indiv_stampy_substitution_rate'} .
        ' --indiv_mapq_filter ' . $params{'indiv_mapq_filter'} .
        ' --quality_trim_reads_thresh ' . $params{'quality_trim_reads_thresh'} .
        ' --quality_trim_reads_consec ' . $params{'quality_trim_reads_consec'} .
        " --parse_or_map parse-only";
    if ($params{'index_file'} && $params{'index_barcodes'}) {
        #print OUT 
        $sScriptBody .= ' --index_file ' . $params{'index_file'} . 
        ' --index_barcodes ' . $params{'index_barcodes'};
    }
    #print OUT 
    $sScriptBody .=    " || exit 100\n";
    #close OUT;

	TemplateFile::WriteWithTemplate("$sSriptDir/template/msgRun1.template",
	{
		'BODY'  => $sScriptBody 
	},
		"msgRun1.$$.sh"
	);

    &Utils::system_call("chmod 755 msgRun1.$$.sh");
}

my $num_barcodes = 0;
if ($params{'msgRun2'}) {
    ### Replace barcodes file if using Illumina indexing since we will now
    ### have num indexes * num barcodes barcoded individuals from parsing step
    if ($params{'index_file'} && $params{'index_barcodes'}) {
        &Utils::system_call("python msg/barcode_splitter.py" .
            ' --make_indexed_msg_barcodes_file' .
            ' --msg_barcodes ' . $params{'barcodes'} .
            ' --bcfile ' . $params{'index_barcodes'});
        $params{'barcodes'} = $params{'barcodes'} . '.after.index.parsing';
    }

    ### Mapping & Plotting
    ### qsub array: one for every 'barcodes_per_job' lines in the barcode file

    open(FILE,$params{'barcodes'}) || die "ERROR (msgCluster): Can't open $params{'barcodes'}: $!\n";
    while (<FILE>) { chomp $_;
        if ($_ =~ /^\S+\t.*$/) {
            $num_barcodes ++;
        }
    } close FILE;
    print "\nnum barcodes is $num_barcodes!\n";

    
    #open (OUT,">msgRun2.$$.sh");
    if ($params{'cluster'} != 0) {
       #print OUT "#!/bin/bash\n/bin/hostname\n/bin/date\n" .
        #    "let start=\"((\${PBS_ARRAYID} - 1) * $params{'barcodes_per_job'}) + 1\"\n" .
        #    "let max_arrayid=\"\$start + $params{'barcodes_per_job'} - 1\"\n" .
        #    "end=\"\$((\$max_arrayid<$num_barcodes?\$max_arrayid:$num_barcodes))\"\n" .
        #    "for ((h=\$start; h<=\$end; h++)); do\n" .
        #    "   sed -n \"\${h}p\" $params{'barcodes'} > $params{'barcodes'}.\$h\n" .
     my $sScriptBody = "";
     $sScriptBody.= '   perl msg/msg.pl ' .
            ' --barcodes ' . $params{'barcodes'} . '.$h' .
            ' --reads ' . $params{'reads'} . 
            ' --parent1 ' . $params{'parent1'} . 
            ' --parent2 ' . $params{'parent2'} .
            ' --chroms ' . $params{'chroms'} .
            ' --sexchroms ' . $params{'sexchroms'} .
            ' --chroms2plot ' . $params{'chroms2plot'} .
            ' --parse_or_map map-only' .
            ' --deltapar1 ' . $params{'deltapar1'} .
            ' --deltapar2 ' . $params{'deltapar2'} .
            ' --recRate ' . $params{'recRate'} .
            ' --rfac ' . $params{'rfac'} .
            ' --priors ' . $params{'priors'} .
            ' --theta ' . $params{'theta'} .
            ' --bwa_alg ' . $params{'bwa_alg'} .
            ' --bwa_threads ' . $params{'bwa_threads'} .
            ' --use_stampy ' . $params{'use_stampy'} .
            ' --stampy_premap_w_bwa ' . $params{'stampy_premap_w_bwa'} .
            ' --indiv_stampy_substitution_rate ' . $params{'indiv_stampy_substitution_rate'} .
            ' --indiv_mapq_filter ' . $params{'indiv_mapq_filter'} .
            ' --gff_thresh_conf ' . $params{'gff_thresh_conf'} .
        ' --new_parser ' . $params{'new_parser'} .
        ' --new_parser_offset ' . $params{'new_parser_offset'} .
        ' --re_cutter ' . $params{'re_cutter'} .
        ' --linker_system ' . $params{'linker_system'} .
        ' --quality_trim_reads_thresh ' . $params{'quality_trim_reads_thresh'} .
        ' --quality_trim_reads_consec ' . $params{'quality_trim_reads_consec'} .
        ' --one_site_per_contig ' . $params{'one_site_per_contig'} .
        ' --new_parser_filter_out_seq ' . ($params{'new_parser_filter_out_seq'} || 'null') .
            " || exit 100 &\n";

	TemplateFile::WriteWithTemplate("$sSriptDir/template/msgRun2.template",
	{
		'BODY'  => $sScriptBody ,
		'BARCODES_PER_JOB' => $params{'barcodes_per_job'}
	},
		"msgRun2.$$.sh"
	);

    } else {
	open (OUT,">msgRun2.$$.sh");
       print OUT "#!/bin/bash\n/bin/hostname\n/bin/date\n" .
            '   perl msg/msg.pl ' .
            ' --barcodes ' . $params{'barcodes'} .
            ' --reads ' . $params{'reads'} . 
            ' --parent1 ' . $params{'parent1'} . 
            ' --parent2 ' . $params{'parent2'} .
            ' --chroms ' . $params{'chroms'} .
            ' --sexchroms ' . $params{'sexchroms'} .
            ' --chroms2plot ' . $params{'chroms2plot'} .
            ' --parse_or_map map-only' .
            ' --deltapar1 ' . $params{'deltapar1'} .
            ' --deltapar2 ' . $params{'deltapar2'} .
            ' --recRate ' . $params{'recRate'} .
            ' --rfac ' . $params{'rfac'} .
            ' --priors ' . $params{'priors'} .
            ' --theta ' . $params{'theta'} .
            ' --bwa_alg ' . $params{'bwa_alg'} .
            ' --bwa_threads ' . $params{'bwa_threads'} .
            ' --use_stampy ' . $params{'use_stampy'} .
            ' --stampy_premap_w_bwa ' . $params{'stampy_premap_w_bwa'} .
            ' --indiv_stampy_substitution_rate ' . $params{'indiv_stampy_substitution_rate'} .
            ' --indiv_mapq_filter ' . $params{'indiv_mapq_filter'} .
            ' --gff_thresh_conf ' . $params{'gff_thresh_conf'} .
        ' --new_parser ' . $params{'new_parser'} .
        ' --new_parser_offset ' . $params{'new_parser_offset'} .
        ' --re_cutter ' . $params{'re_cutter'} .
        ' --linker_system ' . $params{'linker_system'} .
        ' --quality_trim_reads_thresh ' . $params{'quality_trim_reads_thresh'} .
        ' --quality_trim_reads_consec ' . $params{'quality_trim_reads_consec'} .
        ' --one_site_per_contig ' . $params{'one_site_per_contig'} .
        ' --new_parser_filter_out_seq ' . ($params{'new_parser_filter_out_seq'} || 'null') .
           "\n";
    }
    close OUT;
    &Utils::system_call("chmod 755 msgRun2.$$.sh");
}

if ($params{'msgRun3'}) {

    
    #open (OUT,">msgRun3.$$.sh");
    #print OUT "#!/bin/bash\n" .
    my $sSumPlots =    'Rscript msg/summaryPlots.R ' .
        ' -c ' . $params{'chroms'} .
        ' -p ' . $params{'chroms2plot'} .
        ' -d hmm_fit ' .
        ' -t ' . $params{'thinfac'} .
        ' -f ' . $params{'difffac'} .
        ' -b ' . $params{'barcodes'} .
        ' -n ' . $params{'pnathresh'} .
        " || exit 1\n" ;
#!    my $sSumMismatches = 'perl msg/summary_mismatch.pl ' . 
#!        $params{'barcodes'} .
#!        ' 0 ' .
#!        " || exit 1\n" ;
#!    my $sValidation = "#Run a simple validation\n" .
#!        'python msg/validate.py ' .
#!        $params{'barcodes'} .
#!        " || exit 1\n" ;
    my $sCleanUp = "#Cleanup - move output files to folders, remove barcode related files\n" .
        #"mv -f msgRun*.$$.o* msgOut.$$\n" .
        #"mv -f msgRun*.$$.e* msgError.$$\n" .
#!        "mv -f *.trim.log msgOut.$$\n" .
        "rm -f $params{'barcodes'}.*\n";
    
	TemplateFile::WriteWithTemplate("$sSriptDir/template/msgRun3.template",
	{
		'summaryPlots' => $sSumPlots,
#!		'summary_mismatch' =>  $sSumMismatches,
#!		'validation' => $sValidation,
		'cleanup' => $sCleanUp
	},
		"msgRun3.$$.sh"
	);

    &Utils::system_call("chmod 755 msgRun3.$$.sh");
	
	TemplateFile::WriteWithTemplate("$sSriptDir/template/msgWait.template",
	{},
		"msgwait.$$.sh"
	);

    &Utils::system_call("chmod 755 msgwait.$$.sh");
	
	
}
###################################################################################
mkdir "msgOut.$$" unless (-d "msgOut.$$");
mkdir "msgError.$$" unless (-d "msgError.$$");

### Run jobs!
my $val;
my $pwd = getcwd;

my $email = '';
if ($params{'notify_emails'}) {
    $email = '-m ae -M ' . $params{'notify_emails'};
}

if ($params{'msgRun1'}) {
    if ($params{'cluster'} != 0) {
	TemplateFile::WriteWithTemplate("$sSriptDir/template/msgrun1.cmd",
	{
		'PBS_JOB_NAME' , => "msgRun1.$$" ,
		'PWD' => $pwd , 
		'NUM_NODES' => $params{'nodes1'} , 
		'CPU_PER_NODE' => $params{'ppn1'} ,
		'WALLTIME' => $params{'walltime1'}, 
		'PBS_SCRIPT_NAME' => "msgRun1.$$.sh"
	},
		"msgrun1.$$.qsubcmd"
	);
        #$val = &Utils::system_call("qsub -N msgRun1.$$ -d $pwd -l nodes=$params{'nodes1'}:ppn=$params{'ppn1'},walltime=$params{'walltime1'} msgRun1.$$.sh"); 
	$val = &Utils::system_call("bash msgrun1.$$.qsubcmd");
        $val = DeleteSpaces($val);
        printf ("Submitted msgRun1 jobid %s\n", $val);
    } else {
        &Utils::system_call("./msgRun1.$$.sh > msgRun1.$$.out 2> msgRun1.$$.err"); 
    }
}

if ($params{'msgRun2'}) {
    if ($params{'cluster'} != 0) {
        my $array_size = int((${num_barcodes} + $params{'barcodes_per_job'} - 1) / $params{'barcodes_per_job'});
        if ($params{'msgRun1'}) {

		TemplateFile::WriteWithTemplate("$sSriptDir/template/msgrun2.wait_for_run1.cmd",
		{
			'PBS_JOB_NAME' , => "msgRun2.$$" ,
			'PWD' => $pwd , 
			'NUM_NODES' => $params{'nodes2'} , 
			'CPU_PER_NODE' => $params{'ppn2'} ,
			'WALLTIME' => $params{'walltime2'}, 
			'RUN1_JOB_ID' => $val,
			'JOB_START' => 1,
			'JOB_END' => ${array_size},
			'JOB_STEP' => 1,
			'ADD_QSUB_OPT_FOR_EXCLUSIVENODE' =>$params{'addl_qsub_option_for_exclusive_node'},
			'PBS_SCRIPT_NAME' => "msgRun2.$$.sh"
		},
			"msgrun2.$$.qsubcmd"
		);

		$val = &Utils::system_call("bash msgrun2.$$.qsubcmd");

		   #$val = &Utils::system_call("qsub -N msgRun2.$$ -d $pwd -l nodes=$params{'nodes2'}:ppn=$params{'ppn2'},walltime=$params{'walltime2'} -W depend=afterok:$val $params{'addl_qsub_option_for_exclusive_node'} -t 1-${array_size} msgRun2.$$.sh");
        } else {
            TemplateFile::WriteWithTemplate("$sSriptDir/template/msgrun2.nowait.cmd",
		{
			'PBS_JOB_NAME' , => "msgRun2.$$" ,
			'PWD' => $pwd , 
			'NUM_NODES' => $params{'nodes2'} , 
			'CPU_PER_NODE' => $params{'ppn2'} ,
			'WALLTIME' => $params{'walltime2'}, 
			'JOB_START' => 1,
			'JOB_END' => ${array_size},
			'JOB_STEP' => 1,
			'ADD_QSUB_OPT_FOR_EXCLUSIVENODE' =>$params{'addl_qsub_option_for_exclusive_node'},
			'PBS_SCRIPT_NAME' => "msgRun2.$$.sh"
		},
			"msgrun2.$$.qsubcmd"
		);

		$val = &Utils::system_call("bash msgrun2.$$.qsubcmd");
        }
        $val = DeleteSpaces($val);
        #$val =~ s/^(.*)\..*$/$1/;
        printf ("Submitted msgRun2 jobid %s\n", $val);
    } else { 
        &Utils::system_call("./msgRun2.$$.sh > msgRun2.$$.out 2> msgRun2.$$.err");
    }
}

if ($params{'msgRun3'}) {
    if ($params{'cluster'} != 0) {
        if ($params{'msgRun2'}) {
            TemplateFile::WriteWithTemplate("$sSriptDir/template/msgrun3.wait_for_run2.cmd",
		{
			'PBS_JOB_NAME' , => "msgRun3.$$" ,
			'PWD' => $pwd , 
			'NUM_NODES' => $params{'nodes3'} , 
			'CPU_PER_NODE' => $params{'ppn3'} ,
			'WALLTIME' => $params{'walltime3'}, 
			'RUN2_JOB_ID' => $val,
			'ADD_QSUB_OPT_FOR_EXCLUSIVENODE' =>$params{'addl_qsub_option_for_exclusive_node'},
			'EMAIL' => $email,
			'PBS_SCRIPT_NAME' => "msgRun3.$$.sh"
		},
			"msgrun3.$$.qsubcmd"
		);

		$val = &Utils::system_call("bash msgrun3.$$.qsubcmd");
                #$val = &Utils::system_call("qsub -N msgRun3.$$ -d $pwd -l nodes=$params{'nodes3'}:ppn=$params{'ppn3'},mem=$params{'mem3'},walltime=$params{'walltime3'} -W depend=afterokarray:$val $params{'addl_qsub_option_for_exclusive_node'} $email msgRun3.$$.sh");
          
            
        } else {
            TemplateFile::WriteWithTemplate("$sSriptDir/template/msgrun3.nowait.cmd",
			{
				'PBS_JOB_NAME' , => "msgRun3.$$" ,
				'PWD' => $pwd , 
				'NUM_NODES' => $params{'nodes3'} , 
				'CPU_PER_NODE' => $params{'ppn3'} ,
				'WALLTIME' => $params{'walltime3'}, 
				'ADD_QSUB_OPT_FOR_EXCLUSIVENODE' =>$params{'addl_qsub_option_for_exclusive_node'},
				'EMAIL' => $email,
				'PBS_SCRIPT_NAME' => "msgRun3.$$.sh"
			},
				"msgrun3.$$.qsubcmd"
			);

		$val = &Utils::system_call("bash msgrun3.$$.qsubcmd");
                #$val = &Utils::system_call("qsub -N msgRun3.$$ -d $pwd -l nodes=$params{'nodes3'}:ppn=$params{'ppn3'},mem=$params{'mem3'},walltime=$params{'walltime3'} $params{'addl_qsub_option_for_exclusive_node'} $email msgRun3.$$.sh");
                        
        }
        $val = DeleteSpaces($val);
        printf ("Submitted msgRun3 jobid %s\n", $val);
    } else { 
        &Utils::system_call("./msgRun3.$$.sh > msgRun3.$$.out 2> msgRun3.$$.err");
    }
}

#wait for the last step to finish
if ($params{'msgRun3'}) {
    if ($params{'cluster'} != 0) {
		TemplateFile::WriteWithTemplate("$sSriptDir/template/msgwait.cmd",
		{
			'PBS_JOB_NAME' , => "msgwait.$$" ,
			'PREVRUN_JOB_ID' => $val,
			'PBS_SCRIPT_NAME' => "msgwait.$$.sh"
		},
			"msgwait.$$.qsubcmd"
		);
		&Utils::system_call("chmod 755 msgwait.$$.qsubcmd");
		
		print "\nWaiting for msgrun3 to return before continuing...\n";
		$val = &Utils::system_call("bash msgwait.$$.qsubcmd");
		$val = DeleteSpaces($val);
		print "\nmsgrun3 returned...\n";
		
	}
}


print "\nNOTE: Output and error messages are located in: msgOut.$$ and msgError.$$ \n\n";
exit;

sub DeleteSpaces {
	my ($sStr) = @_;
	chomp $sStr;
	return $sStr;
}
