#perl! -w

use strict;

# version 5 - models sequence reads with error in the form of snps and indels -- for SNPs error is modeled as more likely towards the end of the read following an exponential distribution
# version 4 - models sequence reads with "divergence" in the form of snps and indels -- NOT a good model for sequence error because they occur uniformly 
# version 3 - this version restricts the reads to cloned library fragments in a specified size range (low, high) at MseI sites

# usage 
# perl simulate_SRshortreads_MSG_sim.pl sequence_file maxreadlength numreads low_size_lim high_size_lim rate

# no error model is currently implemented, all bases are given maximum QV (=I)
# NOTE - the genome reference file should stochiometrically represent a recombinant diploid or haploid individual
# example: F2 individual, there should be two recombinant genomes
# example: F1 backcross, the file should contain one recombinant genome and one parental genome
# example: haploid progeny, the file should contain only one recombinant genome


if (@ARGV < 6){print "\nusage: zcat ref.fa.gz | perl simulate_SRshortreads_MSG_div.pl recognition_sequence maxreadlength numreads low_size_limit high_size_limit error_rate read_index_start\n\n";exit;}


#################  SET ERROR PARAMETERS HERE ################################################################################

my $indel_mu_scalar = 0;# scalar to multiply indel divergence by 
my $indel_size = 1.2;# mean of exponential that describes indel size distribution

#################  SET ERROR PARAMETERS HERE ################################################################################


use Math::Random qw(:all);

srand(time());

open OUT, ">>reads_sim.fq";

my $recognition_seq = shift(@ARGV); chomp $recognition_seq;#restriction enzyme recognition sequence
my $maxreadlength = shift(@ARGV); chomp $maxreadlength;# read length from Illumina machine 
my $numreads = shift(@ARGV); chomp $numreads;# number of reads
my $low = shift(@ARGV); chomp $low;  # low size limit of simulated library
my $high = shift(@ARGV); chomp $high;  # high size limit of simulated library
my $mut_rate =shift(@ARGV); chomp $mut_rate; #error rate
my $read_index_start=shift(@ARGV); chomp $read_index_start; #counter to append to reads

#**************** read in genome chromosome sequence and create "genome" string

my @data = ();
my @sequence_names = ();
my @sequence_temp =();  
my @data_temp =();
my $genome_length =0; my $seq_count =0; my $sequence_temporary = ""; 
my $genome = "";
$genome = $genome.("N" x $maxreadlength); # initial padding with Ns 

while (<>) { my $line=$_;

	     chomp $line;

	     $line =~ s/\s+//g;# remove all white spaces
	     $line =~ s/type/\ttype/g;# insert a tab

	     if ($line =~ />/) 

	     {

		 $seq_count++;
		 (my $name, my $other) = split(/\t/, $line); chomp $name;
		 push(@sequence_names, $name);
		 $sequence_temporary = join ("", @data_temp);
		 push(@sequence_temp,$sequence_temporary); 
		 @data_temp=();

	     } 

	     else {push(@data_temp, $line);}

}

$sequence_temporary = join ("", @data_temp);
push(@sequence_temp,$sequence_temporary); 

for my $x (0..(scalar(@sequence_names)-1))# assemble "genome" string

{

    $genome = $genome.$sequence_temp[$x+1];
    $genome = $genome.("N" x $maxreadlength); # padding with Ns 

}


my $length = length($genome); 

# catalog all MseI sites in the sequence

my @MseIsites =();

while ($genome =~ /$recognition_seq/g){push(@MseIsites, pos($genome)-4);}


# ****************** generate the short read data 

my $counter = 0;

while ($counter < $numreads){


    my $pos =0; my $site = 0;
    my $diff_right = 0; my $diff_left = 0;
    my $pos_right =0; my $pos_left=0;
    my $read = ""; my $qv ="";  

   
    while (($pos==0) or ($pos<$maxreadlength) or ($pos>($length-$maxreadlength))){

	$site = random_uniform_integer(1, 2, (scalar(@MseIsites)-2));
	$pos = $MseIsites[$site];

    }

    

    my $polarity = random_uniform(1);# direction of read 

    my $minreadlength=0.75*$maxreadlength;
    my $readlength = random_uniform_integer(1, $minreadlength, $maxreadlength);# read length

    $pos_right = $MseIsites[$site+1]; 
    $pos_left  = $MseIsites[$site-1];

    $diff_right = $pos_right + (-1*$pos);
    $diff_left  = $pos + (-1*$pos_left);

    my $read_start=0;

    my $read_polarity=4;

    if (($polarity<=0.5) && ($diff_right>=$low) && ($diff_right<=$high)){# forward read
	$read_polarity = 0;
	$read_start= $pos-($maxreadlength-2);
	$read = substr($genome, $pos+1, $readlength);

    } # forward polarity

    elsif (($diff_left>=$low) && ($diff_left<=$high)) {# reverse read
	$read_polarity = 16;
	$read_start= $pos-($maxreadlength-4)-$readlength;
	$read = rev_comp(substr($genome, $pos-$readlength+3, $readlength));

    } # reverse polarity

    if ($read =~ /N/g){
	$read="";
	#print "excluded\n";
  }

    if ($read ne ""){	
	my $current_read_index=$read_index_start+$counter;
	my @mutated_read = mutate($read, $mut_rate, $indel_mu_scalar, $indel_size);# mutate read

	$counter=$counter+1;

	for my $k (0..(length($mutated_read[0])-1)){$qv = $qv.":";}# read qualities for fastq file, set to 25
	print OUT "\@read$current_read_index\n$mutated_read[0]\n+\n$qv\n";
	

    }

    else{}

    

} # for numreads

close OUT;

#**************************************************************************************************************

# make reverse complement


sub rev_comp {

    my($sequence) = @_;

    
    $sequence =~ s/G/1/go; 
    $sequence =~ s/A/2/go; 
    $sequence =~ s/T/3/go; 
    $sequence =~ s/C/4/go; 
    $sequence =~ s/1/C/go; 
    $sequence =~ s/2/T/go; 
    $sequence =~ s/3/A/go; 
    $sequence =~ s/4/G/go; 

    $sequence = reverse($sequence);

    

    return $sequence;

}



# mutate read

# ****************************************************************************************************************



sub mutate {

    

    my ($sequence, $mutation_rate, $indel_mut_rate_scalar, $indel_size) = @_;

    my @array = ("g", "a", "t", "c");

    my $mut_seq = $sequence;

    my $mu = $mutation_rate * length($sequence);

    my $num_snps=0; my $num_indels=0;

    if ($mu != 0){

	$num_snps = $mu;# number of snp mutations
	$num_indels = random_poisson(1, $mu*$indel_mut_rate_scalar);# number of indel mutations

    }

    my @indel_positions = ();

    my @indel_length = ();
    

    if (($num_snps==0) && ($num_indels==0)){return ($sequence, length($sequence)."M", "MD:Z:".length($sequence));} # if no mutations at all

    else{

	# process snps here

	if ($num_snps !=0){

	    my @snp_positions = random_exponential($num_snps, length($sequence)/10); # positions of snps

	    for my $j (0..(scalar(@snp_positions)-1)){

		my $snp=random_permutation(@array);

	        my $snp_positions_corrected=int(length($sequence)-($snp_positions[$j]));

		while (uc($snp) eq substr($sequence,$snp_positions_corrected-1,1)){$snp=random_permutation(@array);}

		$mut_seq=substr($mut_seq,0,$snp_positions_corrected-1).$snp.substr($mut_seq,$snp_positions_corrected);

	    } # for all snps

	} # if there is > 0 snp muts



	# process indels here

	if ($num_indels !=0){

	    my $check_indels=0;

	    @indel_positions = ();

	    @indel_length = ();

	    while ($check_indels==0){

		my $flag = 0;

		@indel_positions = random_uniform_integer($num_indels, 1, length($sequence));  # positions of indels

		# indel lengths

		for my $k (0..(scalar(@indel_positions)-1)){

		    my @polarity_array = (-1,1);

		    my $indel_len=0; 

		    while($indel_len==0){$indel_len= int(random_exponential(1, $indel_size)+0.5)*random_permutation(@polarity_array)};

		    # print "indel: $indel_len bp pos: $indel_positions[$k]\n";

		    $indel_length[$k]=$indel_len;

		}

		

		if ($num_indels<2){$check_indels=1; }

		else{

		    my %indel_sites =();

		    for my $q (0..(scalar(@indel_positions)-1)){

			if ($indel_length[$q]>0){

			    for my $r (0..$indel_length[$q]-1){

				my $position = $indel_positions[$q]+$r; 

				$indel_sites{$position}++;

				if ($indel_sites{$position}>1){$flag=1;}

			    } # for length of indel

			} # if insertion

			else{   for my $r ($indel_length[$q]+1..0){

			    my $position = $indel_positions[$q]+$r; 

			    $indel_sites{$position}++;

			    if ($indel_sites{$position}>1){$flag=1;}

				} # for length of indel

			} # if deletion

		    } # for all indels

		    if ($flag==0){$check_indels=1; }

		    else{}

		} # if more than one indel

	    } # while check_indels==0 

	    

	    for my $t (0..(scalar(@indel_positions)-1)){

		# process deletions:

		if ($indel_length[$t]<0){

		    while (((-1*$indel_length[$t])+$indel_positions[$t])>length($sequence)){$indel_positions[$t]+=-1; }

		    while ($indel_positions[$t]<2){$indel_positions[$t]++; }

		    if ($indel_length[$t]<0){

			$mut_seq=substr($mut_seq,0,$indel_positions[$t]-1).("_" x (-1*$indel_length[$t])).substr($mut_seq,$indel_positions[$t]-$indel_length[$t]-1);

		    }

		} # if a deletion

		# process insertions:

		elsif ($indel_length[$t]>0){

		    while ($indel_positions[$t]>length($sequence)){$indel_positions[$t]+=-1; } 

		    while ($indel_positions[$t]<2){$indel_positions[$t]++; }

		    my $ins="";

		    $sequence=substr($sequence,0,$indel_positions[$t]-1).("_" x $indel_length[$t]).substr($sequence,$indel_positions[$t]-1);

		    $mut_seq=substr($mut_seq,0,$indel_positions[$t]-1).("x" x $indel_length[$t]).substr($mut_seq,$indel_positions[$t]-1);

		} # if insertion

	    } # for all indels

	} # if there is > 0 indel muts

    } # if there are any muts at all
    

    ###### process cigar based on reference and mutant sequence created above

    my @cigar_elements=();

    my $M=0; my $D=0; my $I=0; my $offset = 0;

    my $converted_ref = $sequence; $converted_ref =~ s/[GATC]/N/g;

    my $converted_mutseq = $mut_seq; $converted_mutseq =~ s/[GATCgatc]/N/g;

    for my $m (0..length($converted_mutseq)-1){

	my $ref_base = substr($converted_ref, $m+$offset, 1);

	my $mut_seq_base = substr($converted_mutseq, $m, 1);

	# matches

	if ($mut_seq_base eq $ref_base){$M++;}

	elsif ($M>0){push(@cigar_elements,$M."M"); $M=0; }

	# deletions

	if ($mut_seq_base eq "_"){$D++;}

	elsif ($D>0){push(@cigar_elements,$D."D"); $D=0; }

	# insertions

	if ($mut_seq_base eq "x"){$I++; }

	elsif ($I>0){push(@cigar_elements,$I."I"); $I=0; }

    } # for all sites

    if ($M>0){push(@cigar_elements,$M."M");}

    my $cigar=""; for my $n (0..scalar(@cigar_elements)-1){$cigar=$cigar.$cigar_elements[$n];}

    

    ###### process MD based on reference and mutant sequence created above

    my @MD_elements=();

    $M=0; $D=""; $I=0; $offset = 0; 

    for my $m (0..length($mut_seq)-1){

	my $ref_base = substr($sequence, $m+$offset, 1);

	my $mut_seq_base = substr($mut_seq, $m, 1);

	# insertions

	if ($mut_seq_base eq "x"){} 

	# matches

	if (($mut_seq_base eq $ref_base) or ($mut_seq_base eq "x")){if ($mut_seq_base eq $ref_base){$M++;}}

	elsif ($M>0){push(@MD_elements,$M); $M=0; }

	# snps

	if (($ref_base ne $mut_seq_base) && ($mut_seq_base =~/[gatc]/)){push(@MD_elements,lc($ref_base));}

	# deletions

	if ($mut_seq_base eq "_"){$D=$D.$ref_base;}

	elsif ($D ne ""){push(@MD_elements,$D."D"); $D=""; }

	

    } # for all sites

    if ($M>0){push(@MD_elements,$M);  }

    

    # construct initial MD

    my $MD=""; 

    for my $n (0..scalar(@MD_elements)-1){

	if ($MD_elements[$n] =~/D/){$MD=$MD."^".$MD_elements[$n];$MD =~s/D//;}

	else{$MD=$MD.$MD_elements[$n];}

    }

    # final processing of MD

    if (substr($MD,0,1)=~/[GATC]/){$MD="0".$MD;}

    if (substr($MD,length($MD)-1,1)=~/[GATC]/){$MD=$MD."0";}

    my $MD_new=$MD;

    for my $z (1..length($MD)-1){

	if ((substr($MD, $z,1)=~/[gatc]/) && (substr($MD, $z-1,1)=~/[gatc]/)){ 

	    $MD_new=substr($MD, 0,$z)."0".substr($MD,$z);

	}

	else{$MD=$MD_new;}

    }

    

    for my $w (0..length($mut_seq)-1){if (substr($mut_seq,$w,1) eq "x"){substr($mut_seq,$w,1)=random_permutation(@array);}}# fill in insertions

    $mut_seq=~ s/\_//g;# remove deletions

    

    

    return (uc($mut_seq), $cigar, $MD);

    

    

} #end sub



