<?php
ini_set ( "memory_limit", '8000M' );
require_once("php_math02/PDL/NormalDistribution.php");
require_once("php_math02/PDL/UniformDistribution.php");
/*
This differs from get_hybrid_genomes_log_normal.php in that
this script only takes size distribution of haplotype blocks
so there are only 2 possible states
Jun-10-2014:
Added option to hook up to external program for block size generation.
The program should output a table of two columns containing block sizes, one for each parent.
In addition to the user-specified command line, the chromosome length will be appended as the 
last parameter
e.g.
If the caller program provide this command line (with -B option):
Rscript exp.R 0.001 1 2 
the following will be excecuted 
Rscript exp.R 0.001 1 2  CHROMOSOME_LEN
Note that if users specified custom distribution files by -x and -y, -B will be ignored.
*/

/*

2014-11-11:

1) identify sites that are AIMs in the parental genome
2) set aside -A of these AIMs
3) assign the remaining AIM sites as polymorphisms, either shared or private
4) If there are more polymorphisms left to be assigned, randomly assign them to other sites in the genome as before
5) put the above categories of sites in different lists
6) assign allele freq from SFS to those lists
7) for each hybrid, create two parents using the lists from step 6), then perform recombination
8) done

*/

/*
2014-12-10
Example:
ref genomes: 20000 AIM differences
Wakeley and Hay feed this program:
AIMs: 15000
Private_poly1: 10000
Private_poly2: 10000
Shared: 2000

Leftover AIMs: 87% become private polys, 13% become shared polys. Then for the remaining private and shared polys that need to be assigned, randomly put them in the genome

*/

/*
2015-2-15
Fixed log output where the last block was output twice.
*/

/*
2015-2-25
Add option -C 0/1 to generate backcross individual. 0 means backcross to parent 1, 1 means backcross to parent 2
*/
/*
2015-3-18
for private polymorphic sites, the prob. for the observed base to be the major allele is calculated as 
1-SFS_freq^2
*/
/*
2015-3-19
fix bug, when polymorphism low program stucks.
*/

$arrOpts = getopt("r:o:1:2:a:b:f:t:H:h:I:i:p:q:P:x:y:B:A:C:");

$nReplicates = $arrOpts["r"]; 
$sOutFolder = $arrOpts["o"]; 
$sPop1Fasta =  $arrOpts["1"];
$sPop2Fasta	=  $arrOpts["2"]; 
$sPop1Code = $arrOpts["a"];
$sPop2Code = $arrOpts["b"];

$sFromScfld =  $arrOpts["f"];
$sToScfld =  $arrOpts["t"];

$nNormalMeanPop1 = array_key_exists("H", $arrOpts)? $arrOpts["H"] : 10;
$nNormalSdPop1	= array_key_exists("h", $arrOpts)? $arrOpts["h"]: 10;
$nNormalMeanPop2 =  array_key_exists("I", $arrOpts)?  $arrOpts["I"]: 10;
$nNormalSdPop2	= array_key_exists("i", $arrOpts)?  $arrOpts["i"]: 10;

$sUserBlockDistPop1 = array_key_exists("x", $arrOpts)? $arrOpts["x"] : ""; 
$sUserBlockDistPop2 = array_key_exists("y", $arrOpts)? $arrOpts["y"] : ""; 

$sUserBlockProgram = array_key_exists("B", $arrOpts)? trim($arrOpts["B"] ): ""; 

$sPolyMorphicDistrFile1 = $arrOpts["p"]; // file containing prob. of each polymorphic site for parent1
$sPolyMorphicDistrFile2 = $arrOpts["q"]; // file containing prob. of each polymorphic site for parent2

$sSharedPolymorphicFile = $arrOpts["P"]; //one number in 0-1
$sFixedAIM = $arrOpts["A"]; //one number in 0-1; added 11-11-14

$nBackCrossTo = array_key_exists("C", $arrOpts)? trim($arrOpts["C"]) : -1; //one number in 0-1; added 11-11-14

if ($nBackCrossTo < -1 || $nBackCrossTo > 1) {
	die("Backcross option -C can only take values 0 or 1\n");
}

if ($nBackCrossTo != -1) {
	echo("Backcross option is on (-C), will perform backcross to parent : ".($nBackCrossTo+1).PHP_EOL);
}


$arrNormal = array();
$arrNormal[0]  = new NormalDistribution($nNormalMeanPop1 , $nNormalSdPop1);
$arrNormal[1] = new NormalDistribution($nNormalMeanPop2 , $nNormalSdPop2);
$oUniformDistrPos = NULL;

$bUserDefinedBlockDist = false; // use a file containing user-specified block size?
$bUserDefinedBlockProgram = false; //use a user-defined program to generate block size?
$hUserBlockDistPop1 = false;
$hUserBlockDistPop2 = false;
$arrUserBlockSizePop = array();
$arrUserBlockSizePop2 = array();
	
if (trim($sUserBlockDistPop1)!="" && trim($sUserBlockDistPop2)!=""){
	$hUserBlockDistPop1 = fopen($sUserBlockDistPop1 , "r");
	$hUserBlockDistPop2 = fopen($sUserBlockDistPop2 , "r");
}


if ($hUserBlockDistPop1!==false && $hUserBlockDistPop2!==false) {
	$bUserDefinedBlockDist = true;
	$arrUserBlockSizePop[0] = fnReadBlockSizes($hUserBlockDistPop1);
	$arrUserBlockSizePop[1] = fnReadBlockSizes($hUserBlockDistPop2);
	//print_r($arrUserBlockSizePop2);
	echo("WARNING: user-specified block size distributions are used (par1=$sUserBlockDistPop1, par2=$sUserBlockDistPop2) . Any options specifed through -H -h -I -i -B will be ignored.".PHP_EOL);
}
else if($sUserBlockProgram!="") {
	$bUserDefinedBlockProgram = true;
	echo("WARNING: user-specified program will be called to generate block size distributions (program=$sUserBlockProgram) . Any options specifed through -H -h -I -i will be ignored.".PHP_EOL);

}
else {
	echo("Using block size distribution parameters: par1=LogNormal($nNormalMeanPop1, $nNormalSdPop1); par2=LogNormal($nNormalMeanPop2, $nNormalSdPop2) ".PHP_EOL);
}
//die();

mkdir($sOutFolder);

$sPop1Seq = strtoupper(fnReadContigs($sPop1Fasta , $sFromScfld ,$sToScfld  ));
echo(strlen($sPop1Seq).PHP_EOL);
$sPop2Seq = strtoupper(fnReadContigs($sPop2Fasta , $sFromScfld ,$sToScfld  ));
echo(strlen($sPop2Seq).PHP_EOL);

if (strlen($sPop1Seq) != strlen($sPop2Seq)) {
	die("The sequence lengths between pop1 and pop2 fasta are different.");
}

$nTotalLen = strlen($sPop1Seq);
echo("Total simualted length: $nTotalLen \n");

$oUniformDistrPos = new UniformDistribution(0 , $nTotalLen - 1);

//write ref genomes
$hHap1 = fopen($sOutFolder."/ref_genome_1.txt", "w");
$hHap2 = fopen($sOutFolder."/ref_genome_2.txt", "w");
fwrite($hHap1 , ">group1".PHP_EOL.$sPop1Seq);
fwrite($hHap2 , ">group1".PHP_EOL.$sPop2Seq);

fclose($hHap1);
fclose($hHap2);

//====================== look for AIMs and partitioning them =================
echo("Finding AIMs... ");
$arrAIMs = fnFindAllAIMs($sPop1Seq , $sPop2Seq);
echo(count($arrAIMs)." differences found between input ref genomes\n");


//================= process polymorphic information ===================
echo("Processing polymorphism information...\n");
$arrPolyMProb = array(); //0 - pop1 , 1-pop2
$arrPolyMProb[0] = fnReadFileToArray($sPolyMorphicDistrFile1);
$arrPolyMProb[1] = fnReadFileToArray($sPolyMorphicDistrFile2);
$arrPolyMProb[2] = $arrSharedProb = fnReadFileToArray($sSharedPolymorphicFile );

if (count($arrPolyMProb[0]) == 0 || count($arrPolyMProb[1]) == 0 || count($arrSharedProb)==0) {
	die("Something wrong with the three polymorphism input files.");
}

//$nSharedSiteProp = $arrSharedProb[0]; // change, now the sharedpoly file does not contain this information. instead, total number of lines is nSharedSite directly.

$nUniquePolySites1  = count($arrPolyMProb[0]);
$nUniquePolySites2 = count($arrPolyMProb[1]);
$nSharedSites = count($arrSharedProb); //intval($nSharedSiteProp * max($nPolySites1,$nPolySites2 ));

$nPolySites1 = $nUniquePolySites1 + $nSharedSites;
$nPolySites2 = $nUniquePolySites2 + $nSharedSites;

if ($nUniquePolySites1 < 0 || $nUniquePolySites2 < 0) {
	die("Too many shared polymorphisms. Note that the percentage of shared polymorphism is based on the parental with more potential polymorphic sites\n");
} 

echo("Parent 1 has a total of $nPolySites1 potentially polymorphic sites, $nSharedSites of which will be shared with parent 2\n");
echo("Parent 2 has a total of $nPolySites2 potentially polymorphic sites\n");

list($arrFixedAIMs , $arrPolymorphicAIMs) = fnPartitionAIMs($arrAIMs , $sFixedAIM);
echo(count($arrFixedAIMs)." differences between two parental ref genome sequences are fixed AIMs\n");
echo(count($arrPolymorphicAIMs)." differences between two parental ref genome sequences are due to shared/private polymorphisms\n");
//die();
$arrPolyConfig = fnConfigPolyMorphicSites();

//print_r($arrPolyConfig);
//die();
//================= end polymorphic information =======================


for($i=0;$i<$nReplicates;$i++) {
	//start making fake stuff.
	echo("Creating individual $i ... \n");

	$arrPop1Seq_Polyadded = array();
	$arrPop2Seq_Polyadded = array();
	
	$arrPop1Seq_Polyadded[0] = fnAddPolyMorphisms($sPop1Seq , $arrPolyConfig['shared'], $arrPolyConfig['unique1'], 0 , $sOutFolder."/".$i."_parent1_chr1_poly.txt");
	$arrPop1Seq_Polyadded[1] = fnAddPolyMorphisms($sPop1Seq , $arrPolyConfig['shared'], $arrPolyConfig['unique1'], 0 , $sOutFolder."/".$i."_parent1_chr2_poly.txt");
	
	$arrPop2Seq_Polyadded[0] = fnAddPolyMorphisms($sPop2Seq , $arrPolyConfig['shared'], $arrPolyConfig['unique2'], 1 , $sOutFolder."/".$i."_parent2_chr1_poly.txt");
	$arrPop2Seq_Polyadded[1] = fnAddPolyMorphisms($sPop2Seq , $arrPolyConfig['shared'], $arrPolyConfig['unique2'], 1 , $sOutFolder."/".$i."_parent2_chr2_poly.txt");
	
	$hIndLog = fopen($sOutFolder."/".$i."_log.txt", "w");

	for ($j=0;$j<2;$j++) {
		//now, initialize block sizes if users specified an external program 
		if ($bUserDefinedBlockProgram) {
			fnInitUserBlockProgram($nTotalLen*2); // to be safe, generate twice as needed.
		}
		
		$nWhichChrPop1 = mt_rand(0,1);
		$nWhichChrPop2 = mt_rand(0,1);
		$sPop1Seq_polyadded = $arrPop1Seq_Polyadded[$nWhichChrPop1];
		$sPop2Seq_polyadded = $arrPop2Seq_Polyadded[$nWhichChrPop2];	
		
		
		$nHapCount = $j + 1;
		echo(" Haploid  $nHapCount ...  \n");
		$hHap1 = null;
		$hAnc1 = null;
		$hHap1 = fopen($sOutFolder."/".$i."_genome_hap$nHapCount.txt", "w");
		$hAnc1 = fopen($sOutFolder."/".$i."_ancestry_hap$nHapCount.txt", "w");
		//$hHap2 = fopen($sOutFolder."/".$i."_genome_hap2.txt", "w");
		//$hAnc2 = fopen($sOutFolder."/".$i."_ancestry_hap2.txt", "w");
		
		$sHap1 = "";

		$sAnc1 = "";

		
		$nPrevState = -1; //previously 0-pop1 1-pop2 or 2-hetero
		$nCurrIndex = 0;
		$nState = 0;
		
		$sHap1Out = ">hap$nHapCount\n";
		//fwrite($hHap1, ">hap$nHapCount\n" );
		//fwrite($hHap2, ">hap2\n");
		fwrite($hAnc1, ">hap$nHapCount\n" );
		//fwrite($hAnc2, ">hap2\n" );
		fwrite($hIndLog, "Len1\tcurrindex\ttotallen\tState\tWhichChr\n");
		
		while($nCurrIndex < $nTotalLen) {
			
			$nState =  (($nBackCrossTo != -1) && $j==1)? $nBackCrossTo : fnGetRandState($nPrevState); // get a random state different from the previous. if create backcross, then always put one parent for j==1 (the second haplotype).
			$nPrevState = $nState;
			//$nLen = round( pow(10, $arrNormal[$nState]->RNG()));
			$nLen = $bUserDefinedBlockDist? fnGetRandUserBlockSize($nState) : (($bUserDefinedBlockProgram)? fnGetRandUserBlockSizeWProgram($nState) : round( pow(10, $arrNormal[$nState]->RNG())) );
			if (($nBackCrossTo != -1) && $j==1) {
				$nLen = $nTotalLen; //if this is the backcross chromosome, don't bother generating blocks.
			}
			
			if ( (1+ $nLen + $nCurrIndex) > $nTotalLen ) {
				$nLen = $nTotalLen - $nCurrIndex ;
				//echo("omg\n");
			}
			
			//echo("Len2: $nLen\n");
			//break;

			if ($nState == 0) {
				$sHap1 = substr($sPop1Seq_polyadded , $nCurrIndex , $nLen);				
				$sAnc1 = str_repeat($sPop1Code , $nLen);
				fwrite($hIndLog, "$nLen\t$nCurrIndex\t$nTotalLen\t$nState\t");
				fwrite($hIndLog, "$nWhichChrPop1\n");

			}
			
			if ($nState == 1) {
				$sHap1 = substr($sPop2Seq_polyadded , $nCurrIndex , $nLen);				
				$sAnc1 = str_repeat($sPop2Code , $nLen);
				fwrite($hIndLog, "$nLen\t$nCurrIndex\t$nTotalLen\t$nState\t");			
				fwrite($hIndLog, "$nWhichChrPop2\n");	

			}
	
			$sHap1Out .= $sHap1;
			//fwrite($hHap1, $sHap1);//.PHP_EOL );
			//fwrite($hHap2, $sHap2);//.PHP_EOL);
			fwrite($hAnc1, $sAnc1);//.PHP_EOL );
			//fwrite($hAnc2, $sAnc2);//.PHP_EOL );
			
			$nCurrIndex += $nLen ;
			//echo($nCurrIndex.PHP_EOL);
		}
		/*
		fwrite($hIndLog, "$nLen\t$nCurrIndex\t$nTotalLen\t$nState\t");
		if ($nState == 0) {
			fwrite($hIndLog, "$nWhichChrPop1\n");
		}
		else {
			fwrite($hIndLog, "$nWhichChrPop2\n");
		}*/
		
		fwrite($hHap1, $sHap1Out);
		$sHap1Out = "";
		fclose($hHap1);
		//fclose($hHap2);
		fclose($hAnc1 );
		//fclose($hAnc2 );
	} 
}

function fnGetRandState($nPrevState) {
	$nRand = -1;
	while(($nRand = mt_rand(0,1 )) == $nPrevState) {
	
	}
	
	return intval($nRand); //returns either 0 or 1
}

function fnReadContigs($sFasta, $sFrom , $sTo) {
	global $sFromScfld, $sToScfld;
	$hFasta = fopen($sFasta , "r");
	$bFromReached = false;
	$bToReached = false;
	$sRet = "";
	
	echo("Reading $sFrom to $sTo from $sFasta\n");
	
	while(($sLn=fgets($hFasta))!==false) {
		$sLn = trim($sLn);
		//echo($sLn);
		
		if (substr($sLn, 0,1) == ">") {
			if ($sFromScfld == substr($sLn, 1)) {
				$bFromReached = true;
				echo("Reached starting point $sFromScfld \n");
				
			}
			if ($sToScfld == substr($sLn, 1)) {
				$bToReached = true;
				echo("Reading last $sToScfld \n");
				continue;
			}
			
			if ($bFromReached && $bToReached) {
				echo("Reading done \n");
				return $sRet;
			}
			
			continue;
		}
		if ($bFromReached ) {
			$sRet .= $sLn;
		}
		
		
	}
	
		if ($bFromReached && $bToReached) {
			echo("Reading done \n");
			return $sRet;
		}
}

function fnReadFileToArray($sF) {
	$hF = fopen($sF, "r");
	$arrRet = array();
	$nLn = 0;
	while(false !== ($sLn = fgets($hF))) {
		$nLn++;
		$sLn = trim($sLn);
		if ($sLn == "") {
			continue;
		}
		if (strtolower($sLn) == "nan") {
			$arrRet[] = 0;
			echo("Warning: setting NaN to 0 on Line $nLn in file $sF\n");
			continue;
		}
		if ( $sLn < 0.0) {
			$arrRet[] = 0;
			echo("Warning: setting $sLn to 0 on Line $nLn in file $sF\n");
			continue;
		}

		$arrRet[] = $sLn;
	}
	
	return $arrRet;
}



function fnConfigPolyMorphicSites() {
//TODO, also consider $arrPolymorphicAIMs , $arrFixedAIMs. First allocate polymorphism to arrPolymorphicAIMs, either shared or not shared. then if more left, assign to other parts of the genome (but not in  arrFixedAIMs)
	global $sPop1Seq, $sPop2Seq, $nSharedSites, $nUniquePolySites1, $nUniquePolySites2, $oUniformDistrPos, $arrPolymorphicAIMs , $arrFixedAIMs;

	$arrPolymorphicAIMsShfled = $arrPolymorphicAIMs ;
	shuffle($arrPolymorphicAIMsShfled); //randomize order of polymorphic aims //TODO: how do I partition these into shared versus unique polymorphisms??

	$nLen = strlen($sPop1Seq);
	$nTotalPoly1 = $nUniquePolySites1 + $nSharedSites;
	$nTotalPoly2 = $nUniquePolySites2 + $nSharedSites;


	
	$nPropUniquePolySites1 = $nUniquePolySites1 / ($nUniquePolySites2 + $nUniquePolySites1 + $nSharedSites);
	$nPropUniquePolySites2 = $nUniquePolySites2 / ($nUniquePolySites2 + $nUniquePolySites1 + $nSharedSites);
	$nPropSharedSites = $nSharedSites / ($nUniquePolySites2 + $nUniquePolySites1 + $nSharedSites);
	
	if ($nLen < max($nTotalPoly1, $nTotalPoly2)) {
		die("Reference sequence length too short for the specified number of polymorphic sites!\n");
	}
	
	$arrSharedPos = array(); 
	$arrUniquePos1 = array();
	$arrUniquePos2 = array();
	$arrOccupiedPos = array();
	
	$nLastInd  = $nLen - 1;
	//fnGetNextRandPos(true); //randomize positions
	//FIND ALL AIMS
	//$arrAIMs = fnFindAllAIMs($sPop1Seq , $sPop2Seq);
	//configure shared sites
	echo("Configuring shared polymorphic sites...\n");
	$nPosCount = 0;

	$nAIMUnique1Polymorphic = intval($nPropUniquePolySites1 * count($arrPolymorphicAIMsShfled));
	$nAIMUnique2Polymorphic = intval($nPropUniquePolySites2 * count($arrPolymorphicAIMsShfled));
	$nAIMSharedPolymorphic = count($arrPolymorphicAIMsShfled) - $nAIMUnique1Polymorphic - $nAIMUnique2Polymorphic ;

	//assign shared polymorphic sites within prelim AIMs and non-AIM regions
	while( $nPosCount <  $nSharedSites ) {
		//echo($nPosCount.PHP_EOL);
		$nCandidatePos = 0;
		if (count($arrPolymorphicAIMsShfled)>0 && $nAIMSharedPolymorphic > 0) { //assign in AIM region
			$nCandidatePos = array_pop($arrPolymorphicAIMsShfled);
			$nAIMSharedPolymorphic--;
		}
		else {			//Assign in non-AIM region
		
			$nCandidatePos = intval($oUniformDistrPos->RNG());
			if (isset( $arrSharedPos[$nCandidatePos] )) { // already looked or is fixed AIM, avoid -> not needed "|| in_array($nCandidatePos , $arrFixedAIMs)"
			continue;
			}
		}
		/*
		if (isset($arrAIMs[$nCandidatePos])) { // avoid any AIMS
			continue;
		}
		*/
		//let aim overlap with polymorphic sites
		
		
		if(is_null($nCandidatePos)) {
			die("Critical Error: all site exhausted.\n");
		}
		
		$sRefBase1 = $sPop1Seq[$nCandidatePos];
		$sRefBase2 = $sPop2Seq[$nCandidatePos];
		
		if ($sRefBase1 == 'N' || $sRefBase2 == 'N') {
			continue; //ignore ambiguous sites.
		}
		
		if ($sRefBase1 != $sRefBase2) {

			$sAltBase1 = $sRefBase2;//fnPickBaseBut($sRefBase1);
			$sAltBase2 = $sRefBase1;//fnPickBaseBut($sRefBase1);
		}
		else { 
			$sAltBase1 = fnPickBaseBut($sRefBase1);
			$sAltBase2 = $sRefBase1;
		}
		
		
		
		$arrSharedPos[$nCandidatePos] = array();
		
		$arrSharedPos[$nCandidatePos][0] = $sRefBase1;//pop1_ref allele
		$arrSharedPos[$nCandidatePos][1] = $sAltBase1;//pop1_alternative allele
		$arrSharedPos[$nCandidatePos][2] = fnGetFreqFromDistr(2); // CHANGED TO 0.5. fnGetFreqFromDistr(0); //frequency of alternative allele
		$arrSharedPos[$nCandidatePos][3] = $sRefBase2;//pop2_ref allele, because not AIM so this is same as refbase1
		$arrSharedPos[$nCandidatePos][4] = $sAltBase2; // pop2 alternative allele
		$arrSharedPos[$nCandidatePos][5] = fnGetFreqFromDistr(2); //changed to 0.5; fnGetFreqFromDistr(1); //frequency of alternative allele
		$nPosCount++;
	}
	
	$arrOccupiedPos = $arrOccupiedPos + array_fill_keys(array_keys($arrSharedPos) , 1); 
	echo("Configuring unique polymorphic sites for parent 1...\n");
	$arrUniquePos1 = fnConfigUniquePolyM($nUniquePolySites1 ,  $arrOccupiedPos ,   0 , $nPropSharedSites , $nPropUniquePolySites1 , $nPropUniquePolySites2,$nAIMUnique1Polymorphic, $arrPolymorphicAIMsShfled);
	$arrOccupiedPos = $arrOccupiedPos + array_fill_keys(array_keys($arrUniquePos1) , 1); 
	echo("Configuring unique polymorphic sites for parent 2...\n");
	$arrUniquePos2 = fnConfigUniquePolyM($nUniquePolySites2 ,  $arrOccupiedPos ,   1 , $nPropSharedSites , $nPropUniquePolySites1 , $nPropUniquePolySites2, $nAIMUnique2Polymorphic, $arrPolymorphicAIMsShfled);

	return array('shared'=>$arrSharedPos, 'unique1' => $arrUniquePos1 , 'unique2' => $arrUniquePos2);
	
}

function fnConfigUniquePolyM($nSites, &$arrOccupiedPos,  $nPop , $nPropSharedSites , $nPropUniquePolySites1 , $nPropUniquePolySites2, $nAIMUniquePolymorphic, &$arrPolymorphicAIMsShfled) {
	global $sPop1Seq, $sPop2Seq, $oUniformDistrPos, $arrPolymorphicAIMs , $arrFixedAIMs;;
	$nLastInd = strlen($sPop1Seq) - 1;
	$arrUniquePos = array(); 
	$nPosCount = 0;

	if (count($arrPolymorphicAIMsShfled) < $nAIMUniquePolymorphic ) {
		die("Critical error: not enough polymorphic AIMs left to be assigned as unique sites\n");
	}


	
	while( $nPosCount  <  $nSites ) {
		//echo("$nPosCount\n");

		$nCandidatePos = 0;
		if (count($arrPolymorphicAIMsShfled)>0 && $nAIMUniquePolymorphic > 0) { //assign in AIM region
			$nCandidatePos = array_pop($arrPolymorphicAIMsShfled);
			$nAIMUniquePolymorphic--;
		}
		else {			//Assign in non-AIM region
		
			$nCandidatePos = intval($oUniformDistrPos->RNG());
			if (isset( $arrUniquePos[$nCandidatePos] ) || isset( $arrOccupiedPos[$nCandidatePos] )) { // already looked or is fixed AIM, avoid
			continue;
			}
		}



		if(is_null($nCandidatePos)) {
			die("Critical Error: all site exhausted.\n");
		}
		
		if (isset( $arrUniquePos[$nCandidatePos] )) { // already looked
			//echo("err1 $nCandidatePos\n");
			continue;
		}
		
		
		
		if (isset( $arrOccupiedPos[$nCandidatePos] )) { // already looked
			//echo("err2 $nCandidatePos\n");
			continue;
		}
		
		
		$sRefBase1 = $sPop1Seq[$nCandidatePos];
		$sRefBase2 = $sPop2Seq[$nCandidatePos];
		$sRefBase = "";
		$sAltBase = "";
		$nSFSFreq = fnGetFreqFromDistr($nPop);
		
		if (strtoupper($sRefBase1)=="N" || strtoupper($sRefBase2)=="N") {
			continue;
		}
		
		if ($sRefBase1 != $sRefBase2) {
			$sRefBase = $sRefBase1 ;
			$sAltBase = $sRefBase2 ;
			if ($nPop==1) {//POP2
				$sRefBase = $sRefBase2 ;
				$sAltBase = $sRefBase1 ;
			}

			if (mt_rand()/mt_getrandmax() <= $nSFSFreq) { // the observed reference allele is actually the minor allele
				$nTmpBase = $sRefBase;
				$sRefBase = $sAltBase;
				$sAltBase = $nTmpBase; //SWAP the major allele as the ref base.
			}
			
		}
		else {
			$sRefBase = $sRefBase1;
			$sAltBase = fnPickBaseBut($sRefBase1);

		}
		

		
		$arrUniquePos[$nCandidatePos] = array();
		
		$arrUniquePos[$nCandidatePos][0] = $sRefBase;//pop1_ref allele
		$arrUniquePos[$nCandidatePos][1] = $sAltBase;//pop1_alternative allele
		$arrUniquePos[$nCandidatePos][2] = $nSFSFreq;//fnGetFreqFromDistr($nPop); //frequency of alternative allele
		$nPosCount++;
	}
	
	return $arrUniquePos;
}

function fnPickBaseBut($sNotThis) {
	$sLeft = str_replace($sNotThis, '', "ATCG");
	return (substr($sLeft , mt_rand(0, strlen($sLeft)-1), 1 ));
}

function fnGetFreqFromDistr($nPop) {
	global $arrPolyMProb;
	$arrp = $arrPolyMProb[$nPop];
	return $arrp[mt_rand(0, count($arrp)-1)];
}

function fnFindAllAIMs(&$sPop1Seq , &$sPop2Seq) {

	$arrRet = array();
	$nLen = strlen($sPop1Seq);
	for ($i=0;$i<$nLen;$i++) {
		$sBase1 = $sPop1Seq[$i];
		$sBase2 = $sPop2Seq[$i];
		if (strtoupper($sBase1)=="N" || strtoupper($sBase2)=="N") {
			continue;
		}

		if($sBase1 != $sBase2) {
			$arrRet[$i] = array();
			$arrRet[$i][0] = $sBase1;
			$arrRet[$i][1] = $sBase2;
		}
	}
	
	return $arrRet;
	
}

function fnPartitionAIMs(&$arrAIMs, $nFixedAIMs) {
	$arrPos = array_keys($arrAIMs);
	$arrPosFixed = array();
	$arrPosPoly = array();

	if ($nFixedAIMs > count($arrPos) ) {
		echo("WARNING: the number of AIMs specified through the command line ($nFixedAIMs) is higher than the observed differences between the two reference sequences. ".count($arrPos)."\nWe will continue by assuming all observed differences are AIMs.".PHP_EOL);
		$nFixedAIMs = count($arrPos);
	}

	echo("These $nFixedAIMs AIMs will be reciprocally fixed (0-based index): ===\n");
	if ($nFixedAIMs == count($arrPos) ) {
		echo("All observed differences between two refs will be treated as AIMs.".PHP_EOL);
		for($i=0;$i<$nFixedAIMs; $i++) {
			echo( $arrPos[$i].PHP_EOL );
			$arrPosFixed[] = $arrPos[$i];
			$arrPos[$i] = -1;
		} 
	}
	else {

		for($i=0;$i<$nFixedAIMs; $i++) {
			$nRandPos = mt_rand( 0 , count($arrPos) - 1 );
			if ($arrPos[$nRandPos] == -1) {
				$i--;
				continue; // already sampled, skip it.
			}
			echo( $arrPos[$nRandPos].PHP_EOL );
			$arrPosFixed[] = $arrPos[$nRandPos];
			$arrPos[$nRandPos] = -1;
		} 
	}


	echo("These observed differences will be treated as polymorphic (0-based index): ===\n");

	foreach($arrPos as $nPolyPos) {
		if ($nPolyPos == -1) {
			continue;
		}
		echo( $nPolyPos.PHP_EOL );
		$arrPosPoly[] = $nPolyPos;
	}

	return array($arrPosFixed , $arrPosPoly);

}

$arrRandPos = array();
function fnGetNextRandPos($bReset) {
	global $sPop1Seq;
	global $arrRandPos;
	if ($bReset) {
		$arrRandPos = range(0, strlen($sPop1Seq)-1);
		shuffle($arrRandPos);
		return;
	}
	
	return array_pop($arrRandPos);
	
	
}


function &fnAddPolyMorphisms(&$sPop1Seq , &$arrShared, &$arrUnique, $nPop, $sLogFile) {
	global $nRandMAX ;
	$hLog = fopen($sLogFile , "w");
	$sLog = "";
	echo("Putting polymorphism on parent $nPop\n");
	$sRet = $sPop1Seq;
	$nPop++;
	foreach($arrShared as $nPos => $arrConfig) {
		if ( (mt_rand() / mt_getrandmax() ) <= $arrConfig[$nPop*3-1] ) { 
			$sRet[$nPos] = $arrConfig[$nPop*3-2];
			$sLog .= "s\t".$nPos."\t".$arrConfig[$nPop*3-3]."\t".$arrConfig[$nPop*3-2]."\t".$arrConfig[$nPop*3-2]."\t".$arrConfig[$nPop*3-1].PHP_EOL;
		}
		else {
			$sRet[$nPos] = $arrConfig[$nPop*3-3]; //ref allele
			$sLog .= "s\t".$nPos."\t".$arrConfig[$nPop*3-3]."\t".$arrConfig[$nPop*3-2]."\t".$arrConfig[$nPop*3-3]."\t".$arrConfig[$nPop*3-1].PHP_EOL;	
		}
	}
	
	foreach($arrUnique as $nPos => $arrConfig) {
		if ( (mt_rand() / mt_getrandmax()) <= $arrConfig[2]) { //sfs is usually 0-0.5, 1-sfs makes the ref allele the more frequent alleles.
			$sRet[$nPos] = $arrConfig[1];
			$sLog .= "u\t".$nPos."\t".$arrConfig[0]."\t".$arrConfig[1]."\t".$arrConfig[1]."\t".$arrConfig[2].PHP_EOL;
		}
		else {
			$sRet[$nPos] = $arrConfig[0]; //ref allele
			$sLog .= "u\t".$nPos."\t".$arrConfig[0]."\t".$arrConfig[1]."\t".$arrConfig[0]."\t".$arrConfig[2].PHP_EOL;
		}
	}
	
	fwrite($hLog , $sLog);
	
	return $sRet;
}

function fnReadBlockSizes($hF) {
	$arrRet = array();
	while(false!==($sLn = fgets($hF))) {
		$sLn = trim($sLn);
		if ($sLn == "") {
			continue;
		}
		$arrRet[] = intval($sLn); 
	}
	if (count($arrRet)==0) {
		die("ERROR: User-specified block size distribution doesn't contain any data.");
	}
	return $arrRet;
}

function fnReadBlockSizes2($arrLns) { // this version reads in a table in an array, each being one line, with the two pops as two columns.
	$arrRet1 = array();//pop1
	$arrRet2 = array();//pop2
	$arrRet1['currIndex'] = -1;
	$arrRet2['currIndex'] = -1; // this variable keeps count of which is the next value to take when drawing.
	//$arrLns = explode(PHP_EOL, $sIn);
	foreach($arrLns as $sLn) {
		$sLn = trim($sLn);
		if ($sLn == "") {
			continue;
		}
		$arrFields = explode("\t", $sLn);
		$arrRet1[] = intval($arrFields[0]); 
		$arrRet2[] = intval($arrFields[1]); 
	}
	if (count($arrRet1)==1 || count($arrRet2)==1) {
		die("ERROR: User-specified block size distribution doesn't contain any data.");
	}
	
	return array($arrRet1, $arrRet2);
}


function fnGetRandUserBlockSize($nPop) {
	global $arrUserBlockSizePop;
	
	return $arrUserBlockSizePop[$nPop][ mt_rand( 0 , count($arrUserBlockSizePop[$nPop]) - 1 ) ];
}


function fnInitUserBlockProgram($nChrSize) {
	global $arrUserBlockSizePop2, $sUserBlockProgram;
	$arrOutput = array();
	$nRetCode = 0;
	exec($sUserBlockProgram." $nChrSize", $arrOutput, $nRetCode);
	if ($nRetCode !== 0) {
		die("Error when generating block sizes from user specified program $sUserBlockProgram $nChrSize".PHP_EOL);
	}
	$arrUserBlockSizePop2 = fnReadBlockSizes2($arrOutput);
}

function fnGetRandUserBlockSizeWProgram($nPop) {
	global $arrUserBlockSizePop2;
	if (!array_key_exists($arrUserBlockSizePop2[$nPop]['currIndex'] + 1, $arrUserBlockSizePop2[$nPop])) {
		die("Error, ran out of items. Pop $nPop \n"."currindex:".$arrUserBlockSizePop2[$nPop]['currIndex']." len:".count($arrUserBlockSizePop2[$nPop]).PHP_EOL);
	}
	return $arrUserBlockSizePop2[$nPop][ ++$arrUserBlockSizePop2[$nPop]['currIndex'] ];
}

?>
