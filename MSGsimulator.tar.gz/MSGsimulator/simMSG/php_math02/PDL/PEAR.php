<?php
class PEAR {
	public static function raiseError($str) {
		die($str);
	}
}
?>