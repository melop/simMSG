	<div id="credits">
	<p>	
	Just <a href='download.php'>download the PDL tarball</a> to a web-enabled directory 
	and point your browser at scripts in the <code>tests</code> directory.	
	</p>
	<p>
	<i>Last updated: May 4, 12:45 PM AST</i>
	</p>
  <p>
  Brought to you by:
  </p>
	<ul>
	  <li>Paul Meagher</li>
	  <li>Mark Hale</li>
	  <li>Jaco van Kooten</li>
	  <li>Michael Bommarito</li>
	  <li>Jesus Castagnetto</li>
	  <li>Thomas Lumley</li>	   
    <li><a href='http://www.math.uah.edu/stat/'>Kyle Siegrist</a></li>
    <li><a href='http://www.math.uah.edu/duehring/'>Dawn Duehring</a></li> 
    <li><a href='http://www.library.cornell.edu/nr/bookcpdf.html'>Numerical Recipes in C</a></li>
    <li><a href='http://www.taygeta.com/research.html'>Taygata Research</a></li>
    <li><a href='http://www.unc.edu/~gfish/'>George S. Fishman</a></li>
    <li><a href='http://www.iro.umontreal.ca/~lecuyer/'>Pierre L'Ecuyer</a></li> 
    <li><a href='http://www.iro.umontreal.ca/~simardr/'>Richard Simard</a></li> 
    <li><a href='http://members.aol.com/johnp71/'>John C. Pezzullo</a></li>  
	</ul>
	</div>
</p>

