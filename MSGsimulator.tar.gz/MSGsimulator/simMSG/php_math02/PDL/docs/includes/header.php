<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<title>PDL Package</title>
		<meta name="description" content="Provides a library of classes for encapsulating common probability distributions." />
		<meta name="robots" content="index, follow" />
		<meta name="keywords" content="php probability distributions, php statistics" />
		<link rel="stylesheet" type="text/css" href="style.css" />
	</head>
	<body>
