<?php
include_once "includes/header.php";
include_once "includes/navbar.php";
include_once "includes/credits.php";
include_once "includes/footer.php";	
?>
