<?php
/*
* @package MR
* @path MR/wmr5.php
*/
require_once "Math/JAMA/Matrix.php";
require_once "Math/PDL/FDistribution.php"; 
require_once "Math/PDL/TDistribution.php"; 

require_once "JpGraph/jpgraph.php";
require_once "JpGraph/jpgraph_scatter.php";
require_once "JpGraph/jpgraph_line.php";
/*
* @author Paul Meagher
* @version 0.5
* @updated March 26, 2006 - 10:00 PM AST
*
* PREAMBLE
*
* MultipleRegression.php is a script intended for 
* web-based multiple regression analysis. The plan is
* to eventually turn it into a MultipleRegression object.
* 
* The source of the Zarthan Company example is:
*
* Neter, J., Wasserman, W., Kutner, M.H. (1990). Applied 
* Linear Statistical Models. 3rd Edition. IRWIN: 
* Boston, MA. 
*
* A 4th edition of this book was published in 1996 with 
* C. J. Nachtsheim added as an author.
* 
* INSTALLATION:
*
* 1. Install the JAMA and PDL packages into your PEAR directory 
*    so that you are able to include package classes like this:
*
*    require_once "Math/JAMA/Matrix.php";
*    require_once "Math/PDL/FDistribution.php"; 
*    require_once "Math/PDL/TDistribution.php"; 
*
*    You can obtain the latest versions of the required JAMA and 
*    PDL packages here:
*
*    JAMA Package => http://www.phpmath.com/~jama/build-05/doc/
*    PDL Package  => http://www.phpmath.com/~pdl/build-02/docs/
*
* 2. Install JpGraph into the PEAR directory as well.  I copied
*    the "JpGraph/src" folder to a folder called "JpGraph" at the  
*    same directory level as the PEAR "Math" folder.
*
*    You can obtain the latest version of JpGraph here: 

*    http://www.aditus.nu/jpgraph/
*
* 3. Create a folder called "MR" anywhere in a PHP-Apache enabled folder.
*
* 4. Create a subfolder called "temp" under the "MR" folder. The 
*    temp folder will need to have web server write permissions so 
*    that graphs can be created in this folder.
*
* 5. Copy the wmr[*].php script to the "MR" folder and point your 
*    browser at it to see the output.
*
* TODO:
*
* 1. Add confidence intervals to the residual prediction error report.
*
* 2. Add an R squared report.
*
* 3. Create a line + scatter plot of the regression curve through the Y data.
*
* 4. Create a web interface to enter data and conduct a multiple regression 
*    analysis.
*/
$yData = array(162,120,223,131,67,169,81,192,116,55,252,232,144,103,212);

$xData = array(array(1, 274, 2450), 
               array(1, 180, 3254),
               array(1, 375, 3802),
               array(1, 205, 2838),
               array(1,  86, 2347),
               array(1, 265, 3782),
               array(1,  98, 3008),
               array(1, 330, 2450),
               array(1, 195, 2137),
               array(1,  53, 2560),
               array(1, 430, 4020),
               array(1, 372, 4427),
               array(1, 236, 2660),
               array(1, 157, 2088),
               array(1, 370, 2605));

$X     = new Matrix($xData);

$nRows = count($xData);
$nCols = count($xData[0]);

$Y     = new Matrix($yData, $nRows);

$Xt    = $X->transpose();
$XtX   = $Xt->times($X);
$XtY   = $Xt->times($Y);
$XtXi  = $XtX->inverse();
$b     = $XtXi->times($XtY);

$Yp    = $X->times($b);
$e     = $Yp->minus($Y); 
$Yt    = $Y->transpose();
$Ytn   = $Yt->times(1/$nRows);
$YtY   = $Yt->times($Y);

$J     = new Matrix( array_fill(0, $nRows, array_fill(0, $nRows, 1)) );
$YtnJ  = $Ytn->times($J);
$YtnJY = $YtnJ->times($Y);

$SSTO  = $YtnJY->minus($YtY);

$bt    = $b->transpose();
$btXt  = $bt->times($Xt);
$btXtY = $btXt->times($Y);

$SSE   = $btXtY->minus($YtY);

$SSR   = $SSE->minus($SSTO);

$dfR  = $nCols - 1;
$dfE  = $nRows - $nCols;  
$dfTO = $nRows - 1;  

$MSR  = $SSR->A[0][0] / $dfR;
$MSE  = $SSE->A[0][0] / $dfE;

$SSB   = $XtXi->times($MSE);

$FObs = $MSR / $MSE;  

// code for F test starts here

$FCrit = .05;

$F = new FDistribution($dfR, $dfE); 

$FProb = 1 - $F->CDF($FObs); 

if ($FProb == 0)
  $FStat = "p < .0000*";
elseif ($TProb[$i] < .00001)
  $FStat = "p < .0000*";
elseif ($FProb < $FCrit)
  $FStat = "p = ".sprintf("%.4f",$FProb)."*";
else 
  $FStat = "p = ".sprintf("%.4f",$FProb);

// code for T test starts here

$TCrit = .05;

$T = new TDistribution($dfE); 

for ($i=0; $i < $nCols; $i++) {
  $TObs[$i]  = $b->A[$i][0] / sqrt($SSB->A[$i][$i]);
  $TProb[$i] = 2 * (1 - $T->CDF($TObs[$i])); 
  if ($TProb[$i] == 0)
    $TStat[$i] = "p < .0000*";
  elseif ($TProb[$i] < .00001)
    $TStat[$i] = "p < .0000*";      
  elseif ($TProb[$i] < $TCrit)
    $TStat[$i] = "p = ".sprintf("%.4f",$TProb[$i])."*";
  else 
    $TStat[$i] = "p = ".sprintf("%.4f",$TProb[$i]);
}

// code for Residuals
?>
<h1>Zarthan Company Example</h1>

<b>Table 1.</b> <i>ANOVA source table</i><br/>

<table border='1' cellpadding='3'>
<tr>
 <th>Source of variation</th>
 <th>SS</th>
 <th>df</th>
 <th>MS</th>
 <th>F Obs</th> 
 <th>F Stat</th>  
</tr>
<tr>
  <td>Regression</td>
  <td>SSR = <?php printf("%.2f", $SSR->A[0][0]) ?></td>
  <td>dfR = <?php echo $dfR ?></td>
  <td>MSR = <?php printf("%.2f", $MSR) ?></td>
  <td>MSR/MSE = <?php printf("%.2f", $FObs) ?></td>  
  <td align='center'><?php echo $FStat ?></td>    
</tr>
<tr>
  <td>Error</td>
  <td>SSE = <?php printf("%.2f", $SSE->A[0][0]) ?></td>
  <td>dfE = <?php echo $dfE ?></td>
  <td>MSE = <?php printf("%.2f", $MSE) ?></td>
  <td>&nbsp;</td>  
  <td>&nbsp;</td>    
</tr>
<tr>
  <td>Total</td>
  <td>SSTO = <?php printf("%.2f", $SSTO->A[0][0]) ?></td>
  <td>dfTO = <?php echo $dfTO ?></td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>  
  <td>&nbsp;</td>    
</tr>
</table>
<b>*</b> indicates signficance

<br/>
<br/>

<b>Table 2.</b> <i>Test of regression parameters</i><br/>

<table border='1' cellpadding='3'>
<tr>
 <th>Parameter</th>
 <th>Estimate</th>
 <th>SE</th> 
 <th>T Obs</th>
 <th>T Stat</th>
</tr>
<tr>
  <td>Intercept</td>
  <td>b<sub>0</sub>=<?php printf("%.4f",$b->A[0][0]) ?></td>
  <td>s{b<sub>0</sub>}=<?php printf("%.4f", sqrt($SSB->A[0][0])) ?></td>
  <td>t<sub>0</sub>=<?php printf("%.2f",$TObs[0]) ?></td>  
  <td align='center'><?php echo $TStat[0] ?></td>
</tr>
<tr>
  <td>Population</td>
  <td>b<sub>1</sub>=<?php printf("%.4f",$b->A[1][0]) ?></td>
  <td>s{b<sub>1</sub>}=<?php printf("%.4f", sqrt($SSB->A[1][1])) ?></td>  
  <td>t<sub>1</sub>=<?php printf("%.2f",$TObs[1]) ?></td>
  <td align='center'><?php echo $TStat[1] ?></td>
</tr>
<tr>
  <td>Income</td>
  <td>b<sub>2</sub>=<?php printf("%.4f",$b->A[2][0]) ?></td>
  <td>s{b<sub>2</sub>}=<?php printf("%.6f", sqrt($SSB->A[2][2])) ?></td>  
  <td>t<sub>2</sub>=<?php printf("%.2f",$TObs[2]) ?></td>
  <td align='center'><?php echo $TStat[2] ?></td>
</tr>
</table>
<b>*</b> indicates signficance

<br/>
<br/>

<b>Table 3.</b> <i>Residual prediction error</i><br/>

<table border='1' cellpadding='3'>
<tr>
 <th>Observation</th>
 <th>Observed Y<sub>i</sub></th>
 <th>Predicted Y<sub>i</sub></th>
 <th>Residual e<sub>i</sub></th>
</tr>
<?php
for ($i=0; $i < $nRows; $i++) {
  ?>
  <tr>
    <td align='center'><?php echo ($i + 1) ?></td>
    <td align='right'><?php printf("%.2f",$Y->A[$i][0]) ?></td>
    <td align='right'><?php printf("%.2f",$Yp->A[$i][0]) ?></td>
    <td align='right'><?php printf("%.2f",$e->A[$i][0]) ?></td>
  </tr>            
  <?php
  $PredictedY[$i] = $Yp->A[$i][0];
  $Error[$i]      = $e->A[$i][0];  
}
?>
</table>

<br>
<br>

<b>Figure 1.</b> <i>Residual plot for predicted Y values.</i><br/>

<?php
$title  = "Residual error";

// Graph displays residuals as function of predicted Y values
$graph = new Graph(300,200,'auto');
$graph->SetScale("linlin");

// Setup title  
$graph->title->Set("$title");
$graph->img->SetMargin(60,20,20,40); 
$graph->xaxis->SetTitle("Predicted Y","center");
$graph->yaxis->SetTitleMargin(40);   
$graph->yaxis->title->Set("Residual"); 

$graph->title->SetFont(FF_FONT1,FS_BOLD);  
$graph->xaxis->SetPos('min');

$sp = new ScatterPlot($Error, $PredictedY);
$sp->mark->SetType(MARK_FILLEDCIRCLE);
$sp->mark->SetFillColor("red");
$sp->SetColor("blue");
$sp->SetWeight(3);
$sp->mark->SetWidth(4);

$graph->Add($sp);

$graph_name = "examples/temp/test.png";
$graph->Stroke($graph_name);
?>
<img src='<?php echo $graph_name ?>' vspace='15'>

<br />
<br />

<hr />
<?php 
highlight_file(basename($_SERVER['PHP_SELF'])); 
?>
<hr />    