<?php 
/**
* @package REGRESS
*
* Class implements Simple Regression analysis.
*
* @author Paul Meagher 
* @license PHP v3.0   
* @version 1.3
* @modified Apr 2, 2006
*/

require_once "Math/PDL/TDistribution.php"; 
require_once "Math/PDL/FDistribution.php"; 

class SimpleRegression { 
   
  var $n; 
  var $X = array(); 
  var $Y = array();   
  var $ConfInt;   
  var $Alpha; 
  var $XMean; 
  var $YMean; 
  var $SumXX; 
  var $SumXY; 
  var $SumYY;   
  var $Slope; 
  var $YInt;   
  var $PredictedY   = array(); 
  var $Error        = array(); 
  var $SquaredError = array(); 
  var $TotalError;   
  var $SumError; 
  var $SumSquaredError;   
  var $ErrorVariance; 
  var $StdErr; 
  var $SlopeStdErr;   
  var $SlopeTVal;  // T value of Slope 
  var $YIntStdErr;     
  var $YIntTVal;   // T value for Y Intercept 
  var $R; 
  var $RSquared;     
  var $DF;         // Degrees of Freedom 
  var $SlopeProb;  // Probability of Slope Estimate 
  var $YIntProb;   // Probability of Y Intercept Estimate 
  var $AlphaTVal;  // T Value for given alpha setting 
  var $ConfIntOfSlope;         
  
  var $format = "%01.6f"; // Used for formatting output   
      
  function SimpleRegression($X, $Y, $ConfidenceInterval) { 

    $numX = count($X); 
    $numY = count($Y); 

    if ($numX != $numY)  
      die("Error: Size of X and Y vectors must be the same."); 

    if ($numX <= 1) 
      die("Error: Size of input array must be at least 2.");       
     
    $this->n                    = $numX; 
    $this->X                    = $X; 
    $this->Y                    = $Y;   

    $this->ConfInt              = $ConfidenceInterval;     
    $this->Alpha                = (100 - $this->ConfInt) / 100; 
     
    $this->XMean                = $this->getMean($this->X); 
    $this->YMean                = $this->getMean($this->Y); 
    $this->SumXX                = $this->getSumXX(); 
    $this->SumYY                = $this->getSumYY(); 
    $this->SumXY                = $this->getSumXY();     
    $this->Slope                = $this->getSlope(); 
    $this->YInt                 = $this->getYInt(); 
    $this->PredictedY           = $this->getPredictedY(); 
    $this->Error                = $this->getError(); 
    $this->SquaredError         = $this->getSquaredError(); 
    $this->SumError             = $this->getSumError(); 
    $this->TotalError           = $this->getTotalError();     
    $this->SumSquaredError      = $this->getSumSquaredError();     
    $this->ErrorVariance        = $this->getErrorVariance();     
    $this->StdErr               = $this->getStdErr();   
    $this->SlopeStdErr          = $this->getSlopeStdErr();          
    $this->YIntStdErr           = $this->getYIntStdErr();              
    $this->SlopeTVal            = $this->getSlopeTVal();             
    $this->YIntTVal             = $this->getYIntTVal();                 
    $this->R                    = $this->getR();                 
    $this->RSquared             = $this->getRSquared();   
    $this->DF                   = $this->getDF();                         
     
     
    // $dist = new Distribution;   
    
    $T = new TDistribution($this->DF);
    
    $this->SlopeProb            = $T->CDF($this->SlopeTVal);
    $this->YIntProb             = $T->CDF($this->YIntTVal);          
    $this->AlphaTVal            = $T->ICDF($this->Alpha); 
                                    
    $this->ConfIntOfSlope       = $this->getConfIntOfSlope();           

    return true; 
  } 

  function getMean($data) {   
    $mean = 0.0; 
    $sum  = 0.0;      
    for ($i = 0; $i < $this->n; $i++)  
      $sum += $data[$i]; 
    $mean  = $sum/$this->n;    
    return $mean; 
  } 

  function getSumXX(){   
    $SumXX = 0.0;      
    for ($i = 0; $i < $this->n; $i++) 
      $SumXX += ($this->X[$i] - $this->XMean) * ($this->X[$i] - $this->XMean); 
    return $SumXX; 
  } 

  function getSumYY(){   
    $SumYY = 0.0;      
    for ($i = 0; $i < $this->n; $i++) 
      $SumYY += ($this->Y[$i] - $this->YMean) * ($this->Y[$i] - $this->YMean); 
    return $SumYY; 
  } 

  function getSumXY(){   
    $SumXY = 0.0;      
    for ($i = 0; $i < $this->n; $i++) 
      $SumXY += ($this->X[$i] - $this->XMean) * ($this->Y[$i] - $this->YMean); 
    return $SumXY; 
  } 

  function getSlope() { 
    $Slope = 0.0; 
    $Slope = $this->SumXY / $this->SumXX; 
    return $Slope; 
  } 

  function getYInt() { 
    $YInt = 0.0; 
    $YInt = $this->YMean - ($this->Slope * $this->XMean); 
    return $YInt; 
  } 

  function getPredictedY(){        
    for ($i = 0; $i < $this->n; $i++) 
      $PredictedY[$i] = $this->YInt + ($this->Slope * $this->X[$i]); 
    return $PredictedY; 
  } 

  function getError() {           
    $Error = array(); 
    for ($i = 0; $i < $this->n; $i++) 
      $Error[$i] = $this->Y[$i] - $this->PredictedY[$i]; 
    return $Error; 
  } 

  function getTotalError() {           
    $TotalError = 0.0; 
    for ($i = 0; $i < $this->n; $i++) 
      $TotalError += pow(($this->Y[$i] - $this->YMean), 2); 
    return $TotalError; 
  } 

  function getSquaredError() {           
    $SquaredError = array(); 
    for ($i = 0; $i < $this->n; $i++) 
      $SquaredError[$i] = pow(($this->Y[$i] - $this->PredictedY[$i]), 2); 
    return $SquaredError; 
  } 

  function getSumError() {    
    $SumError = 0.0;        
    for ($i = 0; $i < $this->n; $i++) 
      $SumError += $this->Error[$i]; 
    return $SumError; 
  } 

  function getSumSquaredError() {    
    $SumSquaredError = 0.0;        
    for ($i = 0; $i < $this->n; $i++) 
      $SumSquaredError += $this->SquaredError[$i]; 
    return $SumSquaredError; 
  } 

  function getErrorVariance() {    
    $ErrorVariance = 0.0;        
    $ErrorVariance = $this->SumSquaredError / ($this->n - 2);    
    return $ErrorVariance; 
  } 

  function getStdErr() {    
    $StdErr = 0.0;        
    $StdErr = sqrt($this->ErrorVariance);    
    return $StdErr; 
  } 

  function getSlopeStdErr() {    
    $SlopeStdErr = 0.0;        
    $SlopeStdErr = $this->StdErr / sqrt($this->SumXX);    
    return $SlopeStdErr; 
  } 

  function getYIntStdErr() {   
    $YIntStdErr = 0.0;        
    $YIntStdErr = $this->StdErr * sqrt(1 / $this->n + pow($this->XMean, 2) / $this->SumXX);    
    return $YIntStdErr; 
  } 

  function getSlopeTVal() {    
    $SlopeTVal = 0.0;        
    $SlopeTVal = $this->Slope / $this->SlopeStdErr;    
    return $SlopeTVal; 
  } 

  function getYIntTVal() {    
    $YIntTVal = 0.0;        
    $YIntTVal = $this->YInt / $this->YIntStdErr;   
    return $YIntTVal; 
  } 

  function getR() {    
    $R = 0.0;        
    $R = $this->SumXY / sqrt($this->SumXX * $this->SumYY); 
    return $R; 
  } 

  function getRSquared() {   
    $RSquared = 0.0;        
    $RSquared = $this->R * $this->R;    
    return $RSquared; 
  } 

  function getDF() {     
    $DF = 0.0;        
    $DF = $this->n - 2; 
    return $DF; 
  } 

  function getConfIntOfSlope() {     
    $ConfIntOfSlope = 0.0;         
    $ConfIntOfSlope = $this->AlphaTVal * $this->SlopeStdErr ;         
    return $ConfIntOfSlope; 
  }
  
  function showTableSummary($x_name, $y_name) {     
    $ConfInt = $this->ConfInt ."%"; 
    ?>     
    <table border='1' cellpadding='3' align='center'> 
      <tr bgcolor='silver'> 
        <th colspan='6'>Table Summary</th> 
      </tr> 
      <tr> 
        <th align='center'><?php echo $x_name ?></th> 
        <th align='center'><?php echo $y_name ?></th> 
        <th align='center'>Predicted</th> 
        <th align='center'>Residual</th> 
        <th align='center'>Lower <?php echo $ConfInt ?></th> 
        <th align='center'>Upper <?php echo $ConfInt ?></th>         
      </tr> 
      <?php 
      for ($i = 0; $i < $this->n; $i++) { 
        $PredictedY   = sprintf($this->format, $this->PredictedY[$i]); 
        $Error        = sprintf($this->format, $this->Error[$i]); 
        $SquaredError = sprintf($this->format, $this->SquaredError[$i]); 
        $Interval     = $this->AlphaTVal * $this->StdErr * sqrt(1 + 1/$this->n + pow(($this->X[$i] - $this->XMean), 2) / $this->SumXX); 
        $LowerBound   = sprintf($this->format,$this->PredictedY[$i] - $Interval);           
        $UpperBound   = sprintf($this->format,$this->PredictedY[$i] + $Interval); 
        echo "<tr>"; 
        echo "  <td align='center'>".$this->X[$i]."</td>"; 
        echo "  <td align='center'>".$this->Y[$i]."</td>"; 
        echo "  <td align='center'>$PredictedY</td>"; 
        echo "  <td align='center'>$Error</td>"; 
        echo "  <td align='center'>$LowerBound</td>";         
        echo "  <td align='center'>$UpperBound</td>"; 
        echo "</tr>"; 
      } 
      ?> 
    </table> 
    <?php 
  } 
   
  function showAnalysisOfVariance() {                   
    $ModelError      = sprintf($this->format, $this->TotalError - $this->SumSquaredError); 
    $FValue          = sprintf($this->format, ($this->TotalError - $this->SumSquaredError) / $this->ErrorVariance);     
    $SumSquaredError = sprintf($this->format, $this->SumSquaredError);             
    $ErrorVariance   = sprintf($this->format, $this->ErrorVariance); 
    $TotalError      = sprintf($this->format, $this->TotalError);                 
    ?>         
    <table border='1' cellpadding='3'> 
      <tr bgcolor='silver'> 
        <th colspan='5'>Analysis Of Variance</th> 
      </tr> 
      <tr> 
        <th>Source</th><th>df</th><th>Sum Of Squares</th><th>Mean Square</th><th>F Value</th> 
      </tr> 
      <tr> 
         <td>Model</td> 
         <td align='right'><?php echo 1 ?></td>           
         <td align='right'><?php echo $ModelError ?></td> 
         <td align='right'><?php echo $ModelError ?></td>         
         <td align='right'><?php echo $FValue ?></td>                
      </tr> 
      <tr> 
         <td>Error</td> 
         <td align='right'><?php echo ($this->n - 2) ?></td>                    
         <td align='right'><?php echo $SumSquaredError ?></td> 
         <td align='right'><?php echo $ErrorVariance ?></td>         
         <td align='right'>&nbsp;</td>                                      
      </tr> 
      <tr> 
         <td>Total</td> 
         <td align='right'><?php echo ($this->n - 1) ?></td>                             
         <td align='right'><?php echo $TotalError ?></td> 
         <td align='right'>&nbsp;</td>         
         <td align='right'>&nbsp;</td>                
      </tr> 
    </table>     
    <?php 
  } 

  function showParameterEstimates() {           
    // Values for Slope 
    $Slope        = sprintf($this->format, $this->Slope);   
    $SlopeStdErr  = sprintf($this->format, $this->SlopeStdErr);                 
    $SlopeTVal    = sprintf($this->format, $this->SlopeTVal); 
    $SlopeProb    = sprintf("%01.5f", $this->SlopeProb);                                            
    // Values for Y Intercept 
    $YInt         = sprintf($this->format, $this->YInt); 
    $YIntStdErr   = sprintf($this->format, $this->YIntStdErr);                     
    $YIntTVal     = sprintf($this->format, $this->YIntTVal);                 
    $YIntProb     = sprintf("%01.5f", $this->YIntProb);                            
    ?>     
    <table border='1' cellpadding='3'> 
      <tr bgcolor='silver'> 
        <th colspan='5'>Parameter Estimates</th> 
      </tr> 
      <tr> 
        <th>Variable</th><th>Estimate</th><th>Std Error</th><th>T Value</th><th>Prob > T</th> 
      </tr> 
      <tr> 
         <td>Slope</td> 
         <td align='right'><?php echo $Slope ?></td> 
         <td align='right'><?php echo $SlopeStdErr ?></td>         
         <td align='right'><?php echo $SlopeTVal ?></td>                
         <td align='right'><?php echo $SlopeProb ?></td>                         
      </tr> 
      <tr> 
         <td>Intercept</td> 
         <td align='right'><?php echo $YInt ?></td> 
         <td align='right'><?php echo $YIntStdErr ?></td>         
         <td align='right'><?php echo $YIntTVal ?></td>                
         <td align='right'><?php echo $YIntProb ?></td>                                              
      </tr> 
    </table> 
    <?php 
  } 

  function showFormula($x_name, $y_name) {     
    $YInt   = sprintf($this->format, $this->YInt); 
    $Slope  = sprintf($this->format, $this->Slope);     
    echo "$y_name = $YInt + ($Slope * $x_name)"; 
  } 

  function showRValues() {               
    $R         = sprintf($this->format, $this->R);     
    $RSquared  = sprintf($this->format, $this->RSquared);             
    ?>     
    <table border='1' cellpadding='3'> 
      <tr bgcolor='silver'> 
        <th colspan='5'>Model Fit</th> 
      </tr>     
      <tr> 
        <th>R</th><th>R Squared</th> 
      </tr> 
      <tr> 
         <td align='right'><?php echo $R ?></td> 
         <td align='right'><?php echo $RSquared ?></td>         
      </tr> 
    </table> 
    <?php 
  }   
        
} 
?> 