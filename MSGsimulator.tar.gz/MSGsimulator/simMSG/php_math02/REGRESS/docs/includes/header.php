<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<title>REGRESS Package</title>
		<meta name="description" content="Library for performing regression analysis." />
		<meta name="robots" content="index, follow" />	
	  <meta name="keywords" content="php regression, REGRESSION, php statistics" />
		<link rel="stylesheet" type="text/css" href="style.css" />
	</head>
	<body>
