	<div id="credits">
	<p>
  Download the <a href='download.php?op=download'>REGRESS Package</a>.
	</p>
	<p>
	<i>Last updated: Apr 2, 2006</i>
	</p>
  <p>
  Brought to you by:
  </p>
	<ul>
	  <li>Paul Meagher</li>
	  <li>Mike Bommarito</li>
	  <li>Xinfeng Qin</li>
	</ul>
	</div>
</p>

