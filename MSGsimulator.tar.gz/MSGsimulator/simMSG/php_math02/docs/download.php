<?php
/**
* Script to create PHP/Math package for download
*
* @author Paul Meagher
* @author Mike Bommarito
* @version 0.3
* @modified Apr 2, 2006
*
* Note: Script requires the PEAR Archive_Tar package be installed:
*
* @see http://pear.php.net/package/Archive_Tar
*/

/*************** CONFIG BEGIN **********************/

// set debug to false to go live
$debug = false;

// set name to the build number/directory 
$buildName = "build02";

// set packages in the library
$pkgNames   = array("JAMA","PDL","REGRESS");

/*************** CONFIG END **********************/

// build directory
$buildDir  = substr(dirname(__FILE__), 0, -5 - strlen($buildName));
   
// switch to PHP/Math build directory
chdir($buildDir);

$tarName = "$buildName.tar.gz";  

$tarPath = $buildDir."$buildName/downloads/".$tarName;

if($_GET['op'] == "download") {  
  
	require_once('Archive/Tar.php');  
	
	$tar   = new Archive_Tar($tarPath);

  // get the root level php, text and html files
  $files = glob("$buildName/*.php");
  $files = array_merge($files, glob("$buildName/*.TXT"));  
  $files = array_merge($files, glob("$buildName/*.html")); 
  $files = array_merge($files, glob("$buildName/docs/*.php"));   
  $files = array_merge($files, glob("$buildName/docs/includes/*.php"));     
       
  for ($i=0; $i<count($pkgNames); $i++) {
    switch($pkgNames[$i]) {
      case "JAMA":
        $files = array_merge($files, glob("$buildName/".$pkgNames[$i]."/*.php"));        
        $files = array_merge($files, glob("$buildName/".$pkgNames[$i]."/*.TXT"));
        $files = array_merge($files, glob("$buildName/".$pkgNames[$i]."/docs/*.php"));
        $files = array_merge($files, glob("$buildName/".$pkgNames[$i]."/docs/includes/*.php"));
        $files = array_merge($files, glob("$buildName/".$pkgNames[$i]."/examples/*.php"));
        $files = array_merge($files, glob("$buildName/".$pkgNames[$i]."/tests/*.php"));        
        $files = array_merge($files, glob("$buildName/".$pkgNames[$i]."/utils/*.php"));                
        break;
        break;
      case "PDL":
        $files = array_merge($files, glob("$buildName/".$pkgNames[$i]."/*.php"));        
        $files = array_merge($files, glob("$buildName/".$pkgNames[$i]."/*.TXT"));
        $files = array_merge($files, glob("$buildName/".$pkgNames[$i]."/docs/*.php"));
        $files = array_merge($files, glob("$buildName/".$pkgNames[$i]."/docs/includes/*.php"));
        $files = array_merge($files, glob("$buildName/".$pkgNames[$i]."/examples/*.php"));
        $files = array_merge($files, glob("$buildName/".$pkgNames[$i]."/tests/*.php"));        
        $files = array_merge($files, glob("$buildName/".$pkgNames[$i]."/functions/*.php"));                
        break;
      case "REGRESS":
        $files = array_merge($files, glob("$buildName/".$pkgNames[$i]."/*.php"));        
        $files = array_merge($files, glob("$buildName/".$pkgNames[$i]."/*.TXT"));
        $files = array_merge($files, glob("$buildName/".$pkgNames[$i]."/docs/*.php"));
        $files = array_merge($files, glob("$buildName/".$pkgNames[$i]."/docs/includes/*.php"));
        $files = array_merge($files, glob("$buildName/".$pkgNames[$i]."/examples/*.php"));
        break;
    }    
  }

  $tar->create($files);

	// create the download url
  $webDir  = substr($_SERVER['PHP_SELF'], 0, -18);
  $urlPath = "http://".$_SERVER['HTTP_HOST'].$webDir."/downloads";
  
  if ($debug) {
    ?>
    <center><b>download url:</b> <?php echo "$urlPath/$tarName"; ?></center>
    <br />
    <table border='1' align='center'>
      <?php
      foreach($files AS $key=>$value) {
        ?>
        <tr>
          <td><?php echo $key ?></td>
          <td><?php echo $value ?></td>        
        </tr>
        <?php
      }
      ?>
    </table>
    <?php
  } else {
    // redirect to download url
	  header("Location: $urlPath/$tarName");
	}
  
}

include_once "includes/header.php";
include_once "includes/navbar.php";
?>
<p>
Download current version: 
</p>
<ul>
 <li><a href='<?php echo $_SERVER['PHP_SELF']."?op=download"; ?>'><?php echo $tarName ?></a></li>
</ul>
<?php
include_once "includes/footer.php";
?>