<center>
  <hr />
    [ <a href="index.php">index.php</a> ] [ <a href="download.php">download.php</a></h2> ]
  <hr />
</center>
