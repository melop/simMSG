	<div id="credits">
	<p>
  Download <a href='download.php?op=download'>build02.tar.gz</a>.
	</p>
	<p>
	<i>Last updated: Apr 3, 2006</i>
	</p>
  <p>
  <font color='red'><b>Warning</b></font>: The PHP/Math library is currently under heavy 
  development. Not everything is currently working because of recent restructurings of 
  the codebase.  In the middle of a break-then-fix development cycle.
  </p>
</p>

