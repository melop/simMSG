args<-commandArgs(TRUE)
ma<-as.numeric(args[1])
ta<-as.numeric(args[2])
xa<-(as.numeric(args[3]))
chr<-(as.numeric(args[4]))

#Define the exponential distribution function
exponential<-function(m,t,x){
M<-rexp(1,rate=(m*t))
round(M*(1/x)*100*1000)
}

#Draw from the function until the chromosome length is generated

ancestry_tract_par1<-{}
ancestry_tract_par2<-{}
total_length=0

while(total_length < chr){
par1_tract<-exponential(ma,ta,xa)
par2_tract<-exponential(1-ma,ta,xa)
ancestry_tract_par1<-c(ancestry_tract_par1,par1_tract)
ancestry_tract_par2<-c(ancestry_tract_par2,par2_tract)
total_length<-total_length+par1_tract+par2_tract
}

write.table(cbind(ancestry_tract_par1,ancestry_tract_par2),row.names=FALSE,col.names=FALSE,sep="\t")
